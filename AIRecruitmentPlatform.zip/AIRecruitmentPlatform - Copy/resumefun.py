import requests

def extract_resume_data(resume_text):
    """
    Extracts structured data from a resume text using the Talent Track API.

    Parameters:
        resume_text (str): The raw text content of the resume.

    Returns:
        dict: The parsed JSON response from the API, or None if an error occurs.
    """
    # Define the API endpoint URL
    url = "https://talent-track.p.rapidapi.com/functions/v1/v1-rapid-extract-resume"

    # Hardcoded API key and host (replace these with your actual credentials)
    API_KEY = "your-rapidapi-key-here"
    API_HOST = "talent-track.p.rapidapi.com"

    # Prepare the payload and headers
    payload = {"resumeText": resume_text}
    headers = {
        "x-rapidapi-key": API_KEY,
        "x-rapidapi-host": API_HOST,
        "Content-Type": "application/json"
    }

    try:
        # Make the POST request to the API
        response = requests.post(url, json=payload, headers=headers)
        
        # Raise an exception if the request was unsuccessful
        response.raise_for_status()
        
        # Parse and return the JSON response
        return response.json()
    
    except requests.exceptions.RequestException as e:
        # Handle any errors that occur during the request
        print(f"An error occurred while making the API request: {e}")
        return None