from __future__ import print_function
import sib_api_v3_sdk
from sib_api_v3_sdk.rest import ApiException
from pprint import pprint
from flask import current_app

def send_interview_notification( participant_email, interview):
    # Configure the Brevo API client
    configuration = sib_api_v3_sdk.Configuration()
    configuration.api_key['api-key'] ="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"
    api_instance = sib_api_v3_sdk.TransactionalEmailsApi(sib_api_v3_sdk.ApiClient(configuration))
    
    # Construct the email content with interview details
    email_content = (
    f"""<!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Interview Notification</title>
        <style>
            body {{
                font-family: Arial, sans-serif;
                line-height: 1.6;
                color: #333333;
                margin: 0;
                padding: 0;
            }}
            .container {{
                max-width: 600px;
                margin: 0 auto;
                padding: 20px;
                border: 1px solid #e4e4e4;
                border-radius: 5px;
            }}
            .header {{
                text-align: center;
                margin-bottom: 20px;
                border-bottom: 2px solid #0072c6;
                padding-bottom: 15px;
            }}
            .header img {{
                max-width: 200px;
                height: auto;
            }}
            .content {{
                padding: 15px 0;
            }}
            .interview-details {{
                background-color: #f9f9f9;
                border-left: 4px solid #0072c6;
                padding: 15px;
                margin: 20px 0;
            }}
            .footer {{
                text-align: center;
                margin-top: 30px;
                padding-top: 15px;
                border-top: 1px solid #e4e4e4;
                font-size: 12px;
                color: #777777;
            }}
            h2 {{
                color: #0072c6;
            }}
            .button {{
                display: inline-block;
                padding: 10px 20px;
                background-color: #0072c6;
                color: white;
                text-decoration: none;
                border-radius: 4px;
                margin-top: 15px;
            }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <img src="https://www.xing.com/imagecache/public/scaled_original_image/eyJ1dWlkIjoiMzljN2QzOWUtNDU4ZC00YjMzLTllN2QtMmUxYzQ5NWMxY2EzIiwiYXBwX2NvbnRleHQiOiJlbnRpdHktcGFnZXMiLCJtYXhfd2lkdGgiOjMyMCwibWF4X2hlaWdodCI6MzIwfQ?signature=fb60dec277dc1765bd4e89961aa90ac9d9ea9215bffdfe2f1f6ca582d4bf7d70" alt="Company Logo" style="display: block; margin: 0 auto;">
                <h2>Interview Notification
                
                </h2>
            </div>
            
            <div class="content">
                <p>Dear Team,</p>
                
                <p>We are pleased to inform you that <strong>{interview['participant_email']}</strong> has been scheduled for an interview.</p>
                
                <div class="interview-details">
                    <h3>📅 Interview Details</h3>
                    
                    <p><strong>Time:</strong> {interview['scheduled_time']}</p>
                    <p><strong>Candidate:</strong> {interview['participant_email']}</p>
                </div>
                
                <p>Please ensure you are available at the scheduled time. Your participation is important for a successful evaluation process.</p>
                
                <p>click  this link to join interview on time <br>
                <a href="http://192.168.0.107:5000/interview/{interview['room_code']}">Return to Interview Session</a></p>
                <p>
                
                <p>If you have any scheduling conflicts, please notify HR immediately.</p>
                
                <div style="text-align: center;">
                    <a href="#" class="button">Add to Calendar</a>
                </div>
            </div>
            
             <p>Check out this video: <a href="https://www.youtube.com/watch?v=Q8fUdOCfd2g">Watch Video</a>.</p> 
            
            <div class="footer">
                <p>Best regards,<br>Your HR Team</p>
                <p>© 2025 Your Company. All rights reserved.</p>
            </div>
        </div>
    </body>
    </html>"""
)
    
    # Define the email settings
    send_smtp_email = sib_api_v3_sdk.SendSmtpEmail(
        sender={"name": "Hire Connect", "email": "mugaphinehas@gmail.com"},  # Changed to a generic sender email
        to=[{"email": participant_email}],
        subject=f"Interview Scheduled for {interview['title']}",
        html_content=email_content
    )
    
    # Make the API call to send the email
    try:
        api_response = api_instance.send_transac_email(send_smtp_email)
        print("Email sent successfully!")
        return api_response
    except ApiException as e:
        print(f"Exception when calling TransactionalEmailsApi->send_transac_email: {e}")
        return None