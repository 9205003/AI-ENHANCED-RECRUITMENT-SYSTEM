import os
import logging
import uuid
from datetime import datetime

def generate_meeting_link(room_id):
    """
    Generate a meeting link using a unique room ID.
    
    This function calls the Whereby API to create a real meeting room.
    
    Args:
        room_id: A unique ID for the meeting room
    
    Returns:
        The host meeting URL with privileges
    """
    import requests
    import json
    from datetime import datetime, timedelta
    
    api_key = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJodHRwczovL2FjY291bnRzLmFwcGVhci5pbiIsImF1ZCI6Imh0dHBzOi8vYXBpLmFwcGVhci5pbi92MSIsImV4cCI6OTAwNzE5OTI1NDc0MDk5MSwiaWF0IjoxNzQzMzYzOTY2LCJvcmdhbml6YXRpb25JZCI6MzEzMzYxLCJqdGkiOiJiNTk3Yjk4Yi04ODRhLTRiZDUtYmExMC1iY2QzNGQ5ZDNiNjcifQ.ByHH7ihLX1Q2qqJM5GjoXjyk1hgW_TUYm0FTbU3GZTI"
    
    if not api_key:
        logging.error("WHEREBY_API_KEY environment variable not set")
        raise ValueError("Whereby API key is required to create meeting rooms")
    
    # Whereby API endpoint for creating rooms
    api_url = "https://api.whereby.dev/v1/meetings"
    
    # Default end date (30 days from now)
    end_date = (datetime.utcnow() + timedelta(days=30)).strftime("%Y-%m-%dT%H:%M:%SZ")
    
    # Configure the room settings
    # Use minimal configuration to avoid API errors
    payload = {
        "endDate": end_date,  # Room will be valid until this date
        "fields": ["hostRoomUrl", "roomUrl"]  # What fields to include in the response
    }
    
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    
    try:
        # Call the Whereby API to create a room
        response = requests.post(api_url, headers=headers, data=json.dumps(payload))
        response.raise_for_status()  # Raise an exception for HTTP errors
        
        # Parse the response
        room_data = response.json()
        
        # Log the full response for debugging
        logging.debug(f"Whereby API response: {room_data}")
        
        # Get the host room URL (this includes the room key for host privileges)
        host_room_url = room_data.get("hostRoomUrl")
        
        # For participants, we'll use the regular room URL
        room_url = room_data.get("roomUrl")
        
        if not host_room_url or not room_url:
            logging.error(f"Whereby API response missing required URLs: {room_data}")
            raise ValueError("Failed to get room URLs from Whereby API")
        
        # Store both URLs in our database model (for room_id reference)
        logging.debug(f"Generated Whereby host meeting link: {host_room_url}")
        logging.debug(f"Generated Whereby participant meeting link: {room_url}")
        
        # Return the host room URL (with privileges)
        return host_room_url
        
    except Exception as e:
        logging.error(f"Error creating Whereby meeting room: {str(e)}")
        # Log more details if available
        if isinstance(e, requests.exceptions.RequestException):
            logging.error(f"Request error: {type(e).__name__}")
        raise ValueError(f"Failed to create Whereby meeting room: {str(e)}")

def send_interview_notificationwhereby(interview):
    """
    Send email notifications to the interviewer and interviewee using Brevo.
    """
    import sib_api_v3_sdk
    from sib_api_v3_sdk.rest import ApiException
    
    # Format the datetime for display
    interview_date = {interview['scheduled_time']}
    interview_time = {interview['scheduled_time']}
    
    # Get the API key from environment
    api_key = "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"
    if not api_key:
        logging.error("BREVO_API_KEY environment variable not set")
        return False
        
    # Configure the Brevo API client
    configuration = sib_api_v3_sdk.Configuration()
    configuration.api_key['api-key'] = api_key
    
    # Create an instance of the API class
    api_instance = sib_api_v3_sdk.TransactionalEmailsApi(sib_api_v3_sdk.ApiClient(configuration))
    
    # Prepare interviewer email
    interviewer_email = "admin@example.com"  # This should be configurable in a real app
    interviewer_name = "Interview Organizer"
    
    # Base URL for our application
    base_url = "http://localhost:5000"  # Should be updated to actual domain in production
    custom_interview_url = f"{base_url}/interview/{interview['room_id']}"
    
    # Compose interviewer email content
    interviewer_subject = f"Interview Scheduled: {interview['title']}"
    interviewer_html_content = f"""
    <h2>Interview Scheduled:{interview['title']}</h2>
    <p><strong>Date:</strong> {interview['scheduled_time']}</p>

    <p><strong>Participant:</strong> {interview['participant_email']}</p>
    
    <h3>How to Join the Interview:</h3>
    <ol>
      <li><strong>Recommended Method:</strong> <a href="{custom_interview_url}">Use our custom interview platform</a> with collaborative code editor and chat.</li>
      <li><strong>Alternative Method:</strong> <a href="{interview['meeting_link']}">Use the external meeting link</a> (only if the custom interface isn't working).</li>
    </ol>
    
    
    <p><strong>Position Type:</strong> {interview['position_type']}</p>
    <p><strong>Skill Level:</strong> {interview['skill_level']}</p>
    <hr>
    <p><em>The interview room will be available at the scheduled time. Join as "Host" when prompted.</em></p>
    """
    
    # Compose participant email content
    participant_subject = f"Invitation: Technical Interview - {interview['title']}"
    participant_html_content = f"""
    <h2>You've been invited to a technical interview: {interview['title']}</h2>
    
    
    <h3>How to Join the Interview:</h3>
    <ol>
      <li><strong>Recommended Method:</strong> <a href="{custom_interview_url}">Use our custom interview platform</a> with collaborative code editor and chat.</li>
      <li><strong>Alternative Method:</strong> <a href="{interview['participant_meeting_link']}">Use the external meeting link</a> (only if the custom interface isn't working).</li>
    </ol>
    
    <hr>
    <h3>Interview Details</h3>
    
    <hr>
    <p><em>Please be prepared 5 minutes before the scheduled time. Make sure your camera and microphone are working properly. Join as "Participant" when prompted.</em></p>
    """
    
    try:
        # Send email to interviewer
        send_email_to_interviewer = False  # Set to False if you only want to notify the participant
        
        if send_email_to_interviewer:
            logging.info(f"Sending interviewer notification for interview {interview.id}")
            
            send_interviewer_email = sib_api_v3_sdk.SendSmtpEmail(
                to=[{"email": interviewer_email, "name": interviewer_name}],
                subject=interviewer_subject,
                html_content=interviewer_html_content,
                sender={"name": "Interview Scheduler", "email": "mugaphinehas@gmail.com"}
            )
            
            try:
                # Send interviewer email
                api_response = api_instance.send_transac_email(send_interviewer_email)
                logging.info(f"Interviewer email sent successfully: {api_response}")
            except ApiException as e:
                logging.error(f"Exception when sending interviewer email: {e}")
        
        # Send email to participant
        logging.info(f"Sending participant notification to {interview['participant_email']}")
        
        send_participant_email = sib_api_v3_sdk.SendSmtpEmail(
             to=[{"email": interview['participant_email']}],
            subject=participant_subject,
            html_content=participant_html_content,
            sender={"name": "Interview Scheduler", "email": "mugaphinehas@gmail.com"}
        )
        
        try:
            # Send participant email
            api_response = api_instance.send_transac_email(send_participant_email)
            logging.info(f"Participant email sent successfully: {api_response}")
            return True
        except ApiException as e:
            logging.error(f"Exception when sending participant email: {e}")
            return False
            
    except Exception as e:
        logging.error(f"Error sending interview notifications: {str(e)}")
        return False
