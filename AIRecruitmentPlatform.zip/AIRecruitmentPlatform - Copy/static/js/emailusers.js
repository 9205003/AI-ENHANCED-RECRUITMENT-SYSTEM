export function sendLoginEmail(userEmail, userName) {
    const apiKey = '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';
    const url = 'https://api.brevo.com/v3/smtp/email';

    const data = {
        sender: { email: 'mugaphinehas@gmail.com', name: 'Hire Connect' },
        to: [{ email: userEmail, name: userName }],
        subject: 'Successful Login Notification',
        htmlContent: `
            <h3>Hello ${userName},</h3>
            <p>You have successfully logged in to your account.</p>
            <p>Thank you for using our service!</p>
        `
    };

    fetch(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'api-key': apiKey
        },
        body: JSON.stringify(data)
    })
    .then(response => {
        if (!response.ok) throw new Error('Network response was not ok');
        return response.json();
    })
    .then(result => console.log('Email sent successfully:', result))
    .catch(error => console.error('Failed to send email:', error));
}

// Example usage after login (replace with actual login trigger)
// sendLoginEmail('user@example.com', 'John Doe');