import { initializeApp } from 'https://www.gstatic.com/firebasejs/11.0.2/firebase-app.js';
import {
    getAuth,
    signInWithPopup,
    GoogleAuthProvider,
    onAuthStateChanged,
    signOut
} from 'https://www.gstatic.com/firebasejs/11.0.2/firebase-auth.js';

const firebaseConfig = JSON.parse(document.getElementById('firebase-config').textContent);
const app = initializeApp(firebaseConfig);
const auth = getAuth();
const provider = new GoogleAuthProvider();

// Keep track of new users
let isNewUser = false;
const CACHE_KEY = 'auth_user_cache';

export function initAuth() {
    // Apply cached user data immediately to prevent flickering
    applyCachedUserData();
    
    // Then set up the auth state listener
    onAuthStateChanged(auth, async (user) => {
        const profileLink = document.getElementById('profile-link');
        const employerDashboard = document.getElementById('employer-dashboard');
        const loginSection = document.getElementById('login-section');
        const userSection = document.getElementById('user-section');
        
        if (user) {
            try {
                // Check if user exists in our database
                const checkUserResponse = await fetch(`/api/check_user/${user.uid}`);
                if (!checkUserResponse.ok) {
                    throw new Error(`HTTP error! status: ${checkUserResponse.status}`);
                }
                
                const checkUserData = await checkUserResponse.json();
                isNewUser = !checkUserData.exists;
                
                if (isNewUser) {
                    // Show the user type selection modal for new users
                    const userTypeModal = new bootstrap.Modal(document.getElementById('user-type-modal'));
                    userTypeModal.show();
                    
                    // Clear any cache to prevent confusion for new users
                    clearUserCache();
                    
                    // Hide login/user sections until user type is selected
                    loginSection.style.display = 'none';
                    userSection.style.display = 'none';
                    profileLink.style.display = 'none';
                    employerDashboard.style.display = 'none';
                    
                    return;
                }
                
                // Continue with login for existing users
                // Pass the user type from the database response
                await completeLogin(user, checkUserData.user_type);
            } catch (error) {
                console.error('User check error:', error);
                clearUserCache();
                await signOut(auth);
            }
        } else {
            // User is logged out
            clearUserCache();
            loginSection.style.display = 'block';
            userSection.style.display = 'none';
            profileLink.style.display = 'none';
            employerDashboard.style.display = 'none';
        }
    });
}

// Apply cached user data to prevent flickering during page load
function applyCachedUserData() {
    const cachedUser = getUserCache();
    if (cachedUser) {
        const profileLink = document.getElementById('profile-link');
        const employerDashboard = document.getElementById('employer-dashboard');
        const loginSection = document.getElementById('login-section');
        const userSection = document.getElementById('user-section');
        
        // Update UI with cached data
        document.getElementById('user-email').textContent = cachedUser.displayName;
        document.getElementById('username').textContent = cachedUser.displayName + '||';
        document.getElementById('acctype').textContent = cachedUser.userType + '||';
        
        loginSection.style.display = 'none';
        userSection.style.display = 'block';
        profileLink.style.display = 'block';
        
        if (cachedUser.userType === 'employer') {
            employerDashboard.style.display = 'block';
        } else {
            employerDashboard.style.display = 'none';
        }
    }
}

// Helper functions for user cache management
function setUserCache(userData) {
    localStorage.setItem(CACHE_KEY, JSON.stringify(userData));
}

function getUserCache() {
    const cachedData = localStorage.getItem(CACHE_KEY);
    return cachedData ? JSON.parse(cachedData) : null;
}

function clearUserCache() {
    localStorage.removeItem(CACHE_KEY);
}

// Function to handle login after user type is selected or for existing users
export async function completeLogin(user, userType = null) {
    try {
        const profileLink = document.getElementById('profile-link');
        const employerDashboard = document.getElementById('employer-dashboard');
        const loginSection = document.getElementById('login-section');
        const userSection = document.getElementById('user-section');
        
        const loginData = {
            uid: user.uid,
            email: user.email,
            displayName: user.displayName
        };
        
        // Add userType if provided (for new users)
        if (userType) {
            loginData.userType = userType;
        }
        
        const response = await fetch('/api/user_login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
            body: JSON.stringify(loginData)
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        
        if (data.status === 'success') {
            // Cache user data to prevent flickering on page reloads
            setUserCache({
                uid: user.uid,
                displayName: user.displayName,
                userType: data.user ? data.user.userType : userType
            });
            
            // If this is a new user, redirect based on user type
            if (isNewUser) {
                if (userType === 'employer') {
                    // Redirect employer to employer profile page
                    window.location.href = '/employer_profile';
                } else {
                    // Redirect candidate to assessment profile page
                    window.location.href = '/assessment/profile';
                }
                return; // Stop execution here since we're redirecting
            }
            
            // Otherwise, continue with normal login flow for existing users
            loginSection.style.display = 'none';
            userSection.style.display = 'block';
            profileLink.style.display = 'block';
            
            document.getElementById('user-email').textContent = user.displayName;
            document.getElementById('username').textContent = user.displayName + '||';
            
            const finalUserType = data.user ? data.user.userType : userType;
            document.getElementById('acctype').textContent = finalUserType + '||';
            
            // Set dashboard visibility based on user type from login response
            if (finalUserType === 'employer') {
                employerDashboard.style.display = 'block';
            } else {
                employerDashboard.style.display = 'none';
            }
        } else {
            throw new Error(data.message || 'Login failed');
        }
    } catch (error) {
        console.error('Session creation error:', error);
        alert('Failed to create session. Please try again.');
        clearUserCache();
        await signOut(auth);
    }
}

export async function submitUserType(userType) {
    const user = auth.currentUser;
    if (user) {
        const modal = bootstrap.Modal.getInstance(document.getElementById('user-type-modal'));
        modal.hide();
        await completeLogin(user, userType);
    }
}

export async function loginWithGoogle() {
    try {
        await signInWithPopup(auth, provider);
        // The session will be created by the onAuthStateChanged listener
    } catch (error) {
        console.error('Login error:', error);
        alert('Failed to login. Please try again.');
        clearUserCache();
    }
}

export async function logout() {
    try {
        const response = await fetch('/api/user_logout');
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        clearUserCache();
        await signOut(auth);
        window.location.href = '/';
    } catch (error) {
        console.error('Logout error:', error);
        alert('Failed to logout. Please try again.');
    }
}