export function initAssessment() {
    let currentStep = 1;
    const totalSteps = 10;

    // Hide all steps except the first one
    for (let i = 2; i <= totalSteps; i++) {
        document.getElementById(`step-${i}`).style.display = 'none';
    }

    function updateProgressBar() {
        const progress = (currentStep / totalSteps) * 100;
        document.getElementById('progress-bar').style.width = `${progress}%`;
        document.getElementById('step-indicator').textContent = `Step ${currentStep} of ${totalSteps}`;
    }

    // Set up next button event listener
    document.getElementById('next-step').addEventListener('click', () => {
        if (validateStep(currentStep)) {
            document.getElementById(`step-${currentStep}`).style.display = 'none';
            currentStep++;
            if (currentStep <= totalSteps) {
                document.getElementById(`step-${currentStep}`).style.display = 'block';
                updateProgressBar();
                document.getElementById('prev-step').disabled = currentStep === 1;
            } else {
                submitAssessment();
            }
        }
    });

    // Set up previous button event listener
    document.getElementById('prev-step').addEventListener('click', () => {
        document.getElementById(`step-${currentStep}`).style.display = 'none';
        currentStep--;
        document.getElementById(`step-${currentStep}`).style.display = 'block';
        updateProgressBar();
        document.getElementById('prev-step').disabled = currentStep === 1;
    });

    // Set up range input value display
    const rangeInputs = document.querySelectorAll('input[type="range"]');
    rangeInputs.forEach(input => {
        input.addEventListener('input', function() {
            const valueDisplay = this.parentElement.querySelector('.rating-value');
            if (valueDisplay) {
                valueDisplay.textContent = this.value;
            }
        });
    });
}

function validateStep(step) {
    const section = document.getElementById(`step-${step}`);
    const required = section.querySelectorAll('[required]');
    let valid = true;

    required.forEach(field => {
        if (!field.value || field.value.trim() === '') {
            valid = false;
            field.classList.add('invalid');
            // Add error message
            const errorMsg = field.nextElementSibling?.classList.contains('error-message')
                ? field.nextElementSibling
                : document.createElement('div');

            if (!field.nextElementSibling?.classList.contains('error-message')) {
                errorMsg.classList.add('error-message', 'text-danger', 'small', 'mt-1');
                errorMsg.textContent = 'This field is required';
                field.parentNode.insertBefore(errorMsg, field.nextSibling);
            }
        } else {
            field.classList.remove('invalid');
            // Remove error message if it exists
            if (field.nextElementSibling?.classList.contains('error-message')) {
                field.nextElementSibling.remove();
            }
        }
    });

    return valid;
}

function cleanResumeText(text) {
    // Remove header and footer markers
    text = text.replace(/---.*?---/gs, '');
    text = text.replace(/--- END OF FILE ---/g, '');

    // Remove page markers
    text = text.replace(/\[Page \d+\]/g, '');

    // Clean up multiple spaces and normalize formatting
    text = text.replace(/\s+/g, ' ').trim();

    return text;
}

// Function to prepare the resume text (clean and truncate)
function prepareResumeForAnalysis(rawText, maxChars = 2500) {
    const cleanedText = cleanResumeText(rawText);
    return cleanedText.slice(0, maxChars); // Truncate to the first 2500 characters
}

// Function to analyze the resume using the API
async function analyzeResume(resumeText, apiKey) {
    const url = 'https://ai-resume-builder-cv-checker-resume-rewriter-api.p.rapidapi.com/analyzeResume?noqueue=1&language=en';
    const options = {
        method: 'POST',
        headers: {
            'x-rapidapi-key': apiKey,
            'x-rapidapi-host': 'ai-resume-builder-cv-checker-resume-rewriter-api.p.rapidapi.com',
            'Content-Type': 'application/json',
            'x-usiapps-req': 'true'
        },
        body: JSON.stringify({ resumeText }) // Convert the body to JSON
    };

    try {
        
        const response = await fetch(url, options);
        if (!response.ok) {
            throw new Error(`API error: ${response.status} ${response.statusText}`);
        }
        const result = await response.json(); // Parse the JSON response
        return result;
    } catch (error) {
        console.error('Error analyzing resume:', error);
        return { error: error.message };
    }
}

function getStepData(step) {
    const section = document.getElementById(`step-${step}`);
    const inputs = section.querySelectorAll('input, select, textarea');
    const data = {};

    inputs.forEach(input => {
        // Handle checkboxes and multi-select properly
        if (input.type === 'checkbox') {
            data[input.name] = input.checked;
        } else if (input.type === 'file') {
            // For file inputs, include the extracted resume text
            if (window.extractedResumeContent) {
                data['extractedResumeContent'] = window.extractedResumeContent;
            } else {
                data['extractedResumeContent'] = 'No resume content extracted';
            }
        } else if (input.multiple) {
            // Handle multi-select elements
            data[input.name] = Array.from(input.selectedOptions).map(option => option.value);
        } else {
            data[input.name] = input.value.trim(); // Trim whitespace
        }
    });

    return data;
}

function sanitizeData(data) {
    const sanitizedData = {};
    for (const key in data) {
        if (data[key] !== null && data[key] !== undefined && data[key] !== '') {
            sanitizedData[key] = data[key];
        } else {
            sanitizedData[key] = 'N/A'; // Default placeholder for empty values
        }
    }
    return sanitizedData;
}

// Main submit assessment function
async function submitAssessment() {
    // Gather all data from all steps
    const currentDate = new Date().toISOString().split('T')[0]; // Format: YYYY-MM-DD
    
    // Process the extracted resume content
    let preparedResumeText = '';
    let analysisReport = null;

    if (window.extractedResumeContent) {
        const apiKey = '90a7af4e77msh080b5db65552bd5p18151ajsn7530ad125db0'; // Replace with your actual API key
        preparedResumeText = prepareResumeForAnalysis(window.extractedResumeContent);

        // Analyze the resume using the API
        analysisReport = await analyzeResume(preparedResumeText, apiKey);
    }

    const formData = {

        dateApplied: currentDate,
      

        // Get data from each step
        profile: sanitizeData(getStepData(1)),
        education: sanitizeData(getStepData(2)),
        experience: sanitizeData(getStepData(3)),
        technical: sanitizeData(getStepData(4)),
        personality: sanitizeData(getStepData(5)),
        problemSolving: sanitizeData(getStepData(6)),
        communication: sanitizeData(getStepData(7)),
        cultural: sanitizeData(getStepData(8)),
        portfolio: sanitizeData(getStepData(9)),
        finalStatement: sanitizeData(getStepData(10)),

        // Include resume-related data
        resume: {
            rawText: window.extractedResumeContent || 'No resume content extracted',
            preparedText: preparedResumeText || 'No prepared text available',
            analysisReport: analysisReport || { error: 'No analysis report generated' }
        }
    };

    // Show loading indicator
    document.getElementById('next-step').disabled = true;
    document.getElementById('next-step').innerHTML =
        '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Submitting...';

    try {
        const response = await fetch('/api/submit_assessment', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(formData),
        });

        if (response.ok) {
            // Show success message before redirecting
            const assessmentContainer = document.querySelector('.assessment-container');
            assessmentContainer.innerHTML = `
                <div class="alert alert-success p-4 text-center">
                    <h3><i class="bi bi-check-circle-fill me-2"></i>Profile Submitted Successfully!</h3>
                    <p class="mt-3">Thank you for completing the profile. You will be redirected to your profile in a moment.</p>
                </div>
            `;

            // Redirect after a short delay
            setTimeout(() => {
                window.location.href = '/profile';
            }, 3000);
        } else {
            throw new Error('Server responded with an error');
        }
    } catch (error) {
        console.error('Assessment submission error:', error);

        // Show error message
        document.getElementById('next-step').disabled = false;
        document.getElementById('next-step').innerHTML = 'Try Again';

        const assessmentContainer = document.querySelector('.assessment-container');
        const errorAlert = document.createElement('div');
        errorAlert.className = 'alert alert-danger mt-3';
        errorAlert.innerHTML =
            '<strong>Error submitting application.</strong> Please try again or contact support.';
        assessmentContainer.prepend(errorAlert);
    }
}