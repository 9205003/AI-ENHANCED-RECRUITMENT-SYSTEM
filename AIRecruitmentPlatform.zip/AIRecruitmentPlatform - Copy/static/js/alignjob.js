/**
 * A function to analyze the match between a CV/resume and a job description
 * @param {string} cvText - The text content of the CV/resume
 * @param {string} jobDescription - The text content of the job description
 * @returns {Promise<object>} - The parsed JSON response from the API
 */
async function analyzeJobMatch(cvText, jobDescription) {
  const url = 'https://cv-resume-to-job-match-analysis-api.p.rapidapi.com/api:QQ6fvSXH/good_fit_external_API';
  
  // Create a blob from the CV text and create a file from it
  const cvBlob = new Blob([cvText], { type: 'text/plain' });
  const cvFile = new File([cvBlob], 'resume.txt', { type: 'text/plain' });
  
  // Create FormData to handle file upload
  const formData = new FormData();
  formData.append('cv', cvFile);
  formData.append('job_description', jobDescription);

  const options = {
    method: 'POST',
    headers: {
      'x-rapidapi-key': 'd19eb4c471msh3c98a5da3c8f216p11aeb5jsn263557d96a5d',
      'x-rapidapi-host': 'cv-resume-to-job-match-analysis-api.p.rapidapi.com',
      // Note: Don't set Content-Type when using FormData; the browser sets it automatically with the boundary
    },
    body: formData
  };

  try {
    const response = await fetch(url, options);
    
    if (!response.ok) {
      throw new Error(`API request failed with status: ${response.status}`);
    }
    
    const result = await response.json();
    return result;
  } catch (error) {
    console.error('Error calling job match API:', error);
    throw error;
  }
}

// Export the function for use in other modules
export default analyzeJobMatch;