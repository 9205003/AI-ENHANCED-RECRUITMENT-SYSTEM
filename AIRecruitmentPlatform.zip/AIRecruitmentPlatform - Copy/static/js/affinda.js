 const affinda_api_key="aff_e9b03fc1b0808577107e2ce989fa159c44d1a4d3"

 let resume = document.getElementById()



 mistral api ="hAF1XVYqK3fLA6KIFaUBspvIgtqnN9Dj"