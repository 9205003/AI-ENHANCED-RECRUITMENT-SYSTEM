// File: firebaseHelper.js
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.15.0/firebase-app.js";
import {
  getDatabase,
  ref,
  get,
} from "https://www.gstatic.com/firebasejs/9.15.0/firebase-database.js";

// Firebase configuration
const appSettings = {
  databaseURL: "https://app-2f40e-default-rtdb.firebaseio.com",
};

// Initialize Firebase app
const app = initializeApp(appSettings);
const database = getDatabase(app);

/**
 * Fetches the raw text of a user's resume by their user ID.
 * @param {string} userId - The unique identifier for the user.
 * @returns {Promise<string|null>} - A promise that resolves to the raw text of the resume or null if not found.
 */
export async function getUserResumeRawText(userId) {
  try {
    // Validate the user ID
    if (!userId) {
      console.error("No user ID provided.");
      return null;
    }

    // Reference to the user's data in the Firebase Realtime Database
    const userRef = ref(database, `users/${userId}`);
    const snapshot = await get(userRef);

    // Check if the user data exists
    if (snapshot.exists()) {
      const userData = snapshot.val();

      // Safely extract the rawText from the resume object
      const resumeData = userData?.profile?.resume?.rawText || null;

      // Log the extracted resume data
      console.log("Resume Raw Text:", resumeData);

      return resumeData; // Return the raw text
    } else {
      console.warn(`No data found for user with ID: ${userId}`);
      return null;
    }
  } catch (error) {
    console.error("Error fetching user resume data:", error);
    return null;
  }
}