import { initializeApp } from "https://www.gstatic.com/firebasejs/9.15.0/firebase-app.js";
import { 
  getDatabase, 
  ref, 
  push, 
  onValue, 
  remove, 
  update 
} from "https://www.gstatic.com/firebasejs/9.15.0/firebase-database.js";
const appsettings = {

    databaseURL: 'https://app-2f40e-default-rtdb.firebaseio.com'
 };



const app= initializeApp(appsettings);
const database = getDatabase(app);
const jobindb= ref(database,"jobs")
const userjobs=ref(database,"employers")



// Set up event listeners for buttons
document.addEventListener('DOMContentLoaded', function() {
    const deleteButtons = document.querySelectorAll('.delete-job-btn');
    const editButtons = document.querySelectorAll('.edit-job-btn');
    
    // Set up delete button listeners
    deleteButtons.forEach(button => {
        button.addEventListener('click', function() {
            const jobId = this.getAttribute('data-job-id');
            
            deleteJob(jobId);
        });
    });
        
    
    // Set up edit button listeners
    editButtons.forEach(button => {
        button.addEventListener('click', function() {
            const jobId = this.getAttribute('data-job-id');
            openEditModal(jobId);
        });
    });
});

// Function to delete a job
function deleteJob(jobId) {
    const employerId = document.getElementById("empid1").textContent;
    
    if (confirm('Are you sure you want to delete this job posting?')) {
        // Create references to both locations
        const jobRef = ref(database, `jobs/${jobId}`);
        const jobRefUsers = ref(database, `employers/${employerId}/jobs/${jobId}`);
        
        // Delete from the first location
        remove(jobRefUsers)
            .then(() => {
                console.log('Job deleted from employer successfully');
                
                // Now delete from the second location
                return remove(jobRef);
            })
            .then(() => {
                console.log('Job deleted from jobs collection successfully');
                
                // Remove the job from the UI
                const jobElement = document.querySelector(`[data-job-id="${jobId}"]`).closest('.list-group-item');
                if (jobElement) {
                    jobElement.remove();
                }
                
                alert('Job deleted successfully');
            })
            .catch(error => {
                console.error('Error deleting job:', error);
                alert('Failed to delete job. Please try again.');
            });
    }
}
// Function to open edit modal
function openEditModal(jobId) {
    // Get the job data from Firebase
    const jobRef = ref(database, `jobs/${jobId}`);
    
    onValue(jobRef, (snapshot) => {
        const jobData = snapshot.val();
        if (jobData) {
            // Populate the modal with job data
            document.getElementById('edit-job-id').value = jobId;
            document.getElementById('edit-job-title').value = jobData.jobTitle || '';
            document.getElementById('edit-job-description').value = jobData.jobDescription || '';
            document.getElementById('edit-job-requirements').value = jobData.jobRequirements || '';
            document.getElementById('edit-job-location').value = jobData.jobLocation || '';
            document.getElementById('edit-job-salary').value = jobData.jobSalary || '';
            
            // Show the modal
            const editModal = new bootstrap.Modal(document.getElementById('editJobModal'));
            editModal.show();
        } else {
            alert('Job data not found');
        }
    }, {
        onlyOnce: true
    });
}

// Function to update job data
function updateJob(event) {
    event.preventDefault();
    
    const jobId = document.getElementById('edit-job-id').value;
    const jobData = {
        jobTitle: document.getElementById('edit-job-title').value,
        jobDescription: document.getElementById('edit-job-description').value,
        jobRequirements: document.getElementById('edit-job-requirements').value,
        jobLocation: document.getElementById('edit-job-location').value,
        jobSalary: document.getElementById('edit-job-salary').value,
        // Preserve the original posting date
        job_posted_on: document.getElementById('edit-job-posted-on').value || new Date().toLocaleDateString()
    };

    
    const jobRef = ref(database, `jobs/${jobId}`);
    const employerId = document.getElementById("empid1").textContent;
    const jobRefUsers = ref(database, `employers/${employerId}/jobs/${jobId}`);
    update(jobRef, jobData)
        .then(() => {
            console.log('Job updated successfully');
            // Close the modal
            const editModal = bootstrap.Modal.getInstance(document.getElementById('editJobModal'));
            editModal.hide();
            
            // Update the UI
            return update(jobRefUsers,jobData)
        })
        .catch(error => {
            console.error('Error updating job:', error);
            alert('Failed to update job. Please try again.');
        });
}

// Add event listener for form submission
document.addEventListener('DOMContentLoaded', function() {
    const editForm = document.getElementById('edit-job-form');
    if (editForm) {
        editForm.addEventListener('submit', updateJob);
    }
});



///view details in full force///

///contact applicant//
///archive///
