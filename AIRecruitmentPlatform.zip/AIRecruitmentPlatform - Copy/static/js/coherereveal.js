const { generateRecruiterReport } = require('./cohereservice');

async function evaluateCandidate() {
  try {
    const cv = "CV text here";
    const jobDescription = "Job description text here";
    const apiKey = "your-cohere-api-key";
    
    const report = await generateRecruiterReport(cv, jobDescription, apiKey);
    console.log("Candidate evaluation:", report);
    // Use the report in your application
  } catch (error) {
    console.error("Error evaluating candidate:", error);
  }
}

