document.addEventListener("DOMContentLoaded", function () {
    const toggleButton = document.getElementById("assistantToggleButton");
    const popupContainer = document.getElementById("assistantPopup");

    // Toggle visibility of the assistant popup
    toggleButton.addEventListener("click", function () {
        if (popupContainer.classList.contains("show")) {
            popupContainer.classList.remove("show");
            popupContainer.style.display = "none"; // Hide completely
        } else {
            popupContainer.style.display = "flex";
            popupContainer.classList.add("show");
        }
    });
});

document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const chatMessages = document.getElementById('chatMessages');
    const userMessageInput = document.getElementById('userMessage');
    const sendButton = document.getElementById('sendButton');
    const themeDropdownItems = document.querySelectorAll('[data-theme]');
    
    // Initialize state
    let isWaitingForResponse = false;
    
    // Send message function
    function sendMessage() {
        const messageText = userMessageInput.value.trim();
        
        if (messageText === '' || isWaitingForResponse) {
            return;
        }
        
        // Add user message to chat
        addMessageToChat(messageText, 'user');
        
        // Clear input
        userMessageInput.value = '';
        
        // Show thinking indicator
        isWaitingForResponse = true;
        addThinkingIndicator();
        
        // Send to backend
        fetch('/api/chat', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ message: messageText }),
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            // Remove thinking indicator
            removeThinkingIndicator();
            
            // Add assistant response to chat
            addMessageToChat(data.response, 'assistant');
            
            isWaitingForResponse = false;
        })
        .catch(error => {
            console.error('Error:', error);
            removeThinkingIndicator();
            addMessageToChat('Sorry, there was an error processing your request. Please try again.', 'assistant');
            isWaitingForResponse = false;
        });
    }
    
    // Add message to chat
    function addMessageToChat(text, sender) {
        const messagesContainer = document.getElementById('chatMessages');
        const table = messagesContainer.querySelector('.message-table');
        
        // Process the text to ensure it doesn't overflow
        let processedText = text;
        
        // If we have extremely long words (over 30 chars), add invisible hyphens to allow breaking
        processedText = processedText.replace(/(\S{30,})/g, function(match) {
            // Insert invisible break opportunity every 15 chars
            let result = '';
            for (let i = 0; i < match.length; i++) {
                result += match[i];
                if (i > 0 && i % 15 === 0 && i < match.length - 1) {
                    // Add zero-width space to allow breaking
                    result += '\u200B';
                }
            }
            return result;
        });
        
        // Create table row
        const messageRow = document.createElement('tr');
        messageRow.className = `message ${sender}`;
        
        // Create table cell
        const messageCell = document.createElement('td');
        messageCell.className = 'message-cell';
        
        // Create message content
        const messageContent = document.createElement('div');
        messageContent.className = 'message-content';
        messageContent.textContent = processedText;
        
        // Append elements
        messageCell.appendChild(messageContent);
        messageRow.appendChild(messageCell);
        table.appendChild(messageRow);
        
        // Scroll to bottom
        setTimeout(() => {
            messagesContainer.scrollTop = messagesContainer.scrollHeight;
        }, 100);
    }
    
    // Add thinking indicator
    function addThinkingIndicator() {
        const messagesContainer = document.getElementById('chatMessages');
        const table = messagesContainer.querySelector('.message-table');
        
        // Create table row
        const thinkingRow = document.createElement('tr');
        thinkingRow.className = 'message assistant thinking';
        thinkingRow.id = 'thinkingIndicator';
        
        // Create table cell
        const thinkingCell = document.createElement('td');
        thinkingCell.className = 'message-cell';
        
        // Create message content
        const thinkingContent = document.createElement('div');
        thinkingContent.className = 'message-content';
        thinkingContent.innerHTML = '<div class="thinking-dots"><span>.</span><span>.</span><span>.</span></div>';
        
        // Append elements
        thinkingCell.appendChild(thinkingContent);
        thinkingRow.appendChild(thinkingCell);
        table.appendChild(thinkingRow);
        
        // Scroll to bottom
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }
    
    // Remove thinking indicator
    function removeThinkingIndicator() {
        const thinkingIndicator = document.getElementById('thinkingIndicator');
        if (thinkingIndicator) {
            thinkingIndicator.remove();
        }
    }
    
    

    
    // Theme switcher
    function setTheme(theme) {
        document.body.setAttribute('data-theme', theme);
        localStorage.setItem('assistantTheme', theme);
    }
    
    // Initialize theme from local storage
    const savedTheme = localStorage.getItem('assistantTheme') || 'corporate';
    setTheme(savedTheme);
    
    // Event Listeners
    sendButton.addEventListener('click', sendMessage);
    
    userMessageInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            sendMessage();
        }
    });
    
    themeDropdownItems.forEach(item => {
        item.addEventListener('click', function(e) {
            e.preventDefault();
            const theme = this.getAttribute('data-theme');
            setTheme(theme);
        });
    });
    

});