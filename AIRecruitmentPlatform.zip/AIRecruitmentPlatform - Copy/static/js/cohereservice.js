/**
 * Parses the AI analysis response into a structured format
 * @param {string} text - Raw text response from Cohere API
 * @returns {Object} Structured analysis object
 */
function parseAnalysisResponse(text) {
  
    try {
      // Initialize the analysis result structure
      const analysis = {
        strengths: [],
        weaknesses: [],
        clarifications: [],
        matchTags: [],
        skills: { items: [] },
        experience: { items: [] }
      };
  
      // Extract suitability score
      const scoreMatch = text.match(/Suitability Score[\s\n:]+(\d+)/i);
      if (scoreMatch && scoreMatch[1]) {
        analysis.suitabilityScore = parseInt(scoreMatch[1], 10);
      }
  
      // Extract match summary based on suitability score or text content
      if (scoreMatch && scoreMatch[1]) {
        const score = parseInt(scoreMatch[1], 10);
        
        if (score >= 80) {
          analysis.matchSummary = "EXCELLENT MATCH";
          analysis.matchDescription = "The candidate is an excellent match for the position with most key requirements met.";
          analysis.matchTags = ["Strong Match", "Highly Relevant"];
        } else if (score >= 60) {
          analysis.matchSummary = "GOOD MATCH";
          analysis.matchDescription = "The candidate is a good match for the position, meeting many of the requirements.";
          analysis.matchTags = ["Good Match", "Minor Gaps"];
        } else if (score >= 40) {
          analysis.matchSummary = "POTENTIAL MATCH";
          analysis.matchDescription = "The candidate meets some key requirements but has significant gaps.";
          analysis.matchTags = ["Potential Match", "Significant Gaps"];
        } else {
          analysis.matchSummary = "LOW MATCH";
          analysis.matchDescription = "The candidate's profile does not align well with the job requirements.";
          analysis.matchTags = ["Low Match", "Major Skill Gaps"];
        }
      } else if (text.includes("Exceptional match") || text.includes("Strong match")) {
        analysis.matchSummary = "EXCELLENT MATCH";
        analysis.matchDescription = "The candidate is an excellent match for the position with most key requirements met.";
        analysis.matchTags = ["Strong Match", "Highly Relevant"];
      } else if (text.includes("Moderate match")) {
        analysis.matchSummary = "POTENTIAL MATCH";
        analysis.matchDescription = "The candidate meets some key requirements but has significant gaps.";
        analysis.matchTags = ["Potential Match", "Significant Gaps"];
      } else {
        analysis.matchSummary = "LOW MATCH";
        analysis.matchDescription = "The candidate's profile does not align well with the job requirements.";
        analysis.matchTags = ["Low Match", "Major Skill Gaps"];
      }
  
      // Parse skills analysis
      const skillsMatch = text.match(/• Skills Analysis([\s\S]*?)(?=•|➔|$)/);
      if (skillsMatch && skillsMatch[1]) {
        analysis.skills = {
          summary: skillsMatch[1].trim(),
          items: []
        };
  
        // Extract skill items
        const skillItems = skillsMatch[1].match(/- ([^\n]+)/g);
        if (skillItems) {
          analysis.skills.items = skillItems.map(item => item.replace(/^- /, '').trim());
        }
      }
  
      // Parse job titles analysis
      const jobTitlesMatch = text.match(/• Job Titles Analysis([\s\S]*?)(?=•|➔|$)/);
      if (jobTitlesMatch && jobTitlesMatch[1]) {
        analysis.jobTitles = {
          summary: jobTitlesMatch[1].trim()
        };
      }
  
      // Parse professional experience analysis
      const experienceMatch = text.match(/• Professional Experience Analysis([\s\S]*?)(?=•|➔|$)/);
      if (experienceMatch && experienceMatch[1]) {
        analysis.experience = {
          summary: experienceMatch[1].trim(),
          items: []
        };
  
        // Extract experience items
        const expItems = experienceMatch[1].match(/- ([^\n]+)/g);
        if (expItems) {
          analysis.experience.items = expItems.map(item => item.replace(/^- /, '').trim());
        }
      }
  
      // Parse education analysis
      const educationMatch = text.match(/• Education Analysis([\s\S]*?)(?=•|➔|$)/);
      if (educationMatch && educationMatch[1]) {
        analysis.education = {
          summary: educationMatch[1].trim()
        };
      }
  
      // Parse other relevant data
      const otherMatch = text.match(/• Other Relevant Data Analysis([\s\S]*?)(?=•|➔|$)/);
      if (otherMatch && otherMatch[1]) {
        analysis.other = {
          summary: otherMatch[1].trim()
        };
      }
  
      // Parse strengths
      const strengthsMatch = text.match(/➔ Strengths([\s\S]*?)(?=➔|$)/);
      if (strengthsMatch && strengthsMatch[1]) {
        const strengths = strengthsMatch[1].match(/- ([^\n]+)/g);
        if (strengths) {
          analysis.strengths = strengths.map(item => item.replace(/^- /, '').trim());
        }
      }
  
      // Parse weaknesses
      const weaknessesMatch = text.match(/➔ Weaknesses([\s\S]*?)(?=➔|$)/);
      if (weaknessesMatch && weaknessesMatch[1]) {
        const weaknesses = weaknessesMatch[1].match(/- ([^\n]+)/g);
        if (weaknesses) {
          analysis.weaknesses = weaknesses.map(item => item.replace(/^- /, '').trim());
        }
      }
  
      // Parse points needing clarification
      const clarificationsMatch = text.match(/➔ Points Needing Clarification([\s\S]*?)(?=➔|$)/);
      if (clarificationsMatch && clarificationsMatch[1]) {
        const clarifications = clarificationsMatch[1].match(/- ([^\n]+)/g);
        if (clarifications) {
          analysis.clarifications = clarifications.map(item => item.replace(/^- /, '').trim());
        }
      }
  
      return analysis;
    } catch (error) {
      console.error("Error parsing Cohere response:", error);
      throw new Error("Failed to parse analysis response");
    }
  }
  
  /**
   * Analyzes the match between a CV and job description using Cohere AI
   * @param {string} cvText - The candidate's CV or resume text
   * @param {string} jobDescription - The job description text
   * @param {string} apiKey - Your Cohere API key
   * @param {Object} options - Additional options (model, temperature, etc.)
   * @returns {Promise<Object>} Analysis results
   */
  async function analyzeMatch(cvText, jobDescription, apiKey, options = {}) {
    toggleLoader(true);
    try {
      if (!apiKey) {
        throw new Error("Cohere API key is required");
      }
  
      const defaultOptions = {
        model: "command-r-plus",
        maxTokens: 2000,
        temperature: 0.1
      };
  
      const settings = { ...defaultOptions, ...options };
  
      const prompt = `
  You are a highly precise expert HR consultant with deep experience in analyzing CV/resume matches against job descriptions. Your task is to provide a detailed, data-driven analysis with specific examples from both documents.
  
  Follow this exact structure in your analysis:
  
  • Skills Analysis
  Perform a detailed comparison of the candidate's technical and soft skills against the job requirements. Be specific about which skills match and which don't.
  - List each matching skill with evidence from the CV
  - Identify skills mentioned in the job description but missing from the CV
  - Conclude with an overall assessment of skill alignment percentage
  
  • Job Titles Analysis
  Analyze how closely the candidate's previous job titles align with the target position.
  - Compare specific titles
  - Consider industry relevance and seniority level
  - Note if titles suggest relevant expertise even if they don't match exactly
  
  • Professional Experience Analysis
  Examine whether the candidate's work experience prepares them for the responsibilities in the job description.
  - Compare specific duties and achievements from the CV against job requirements
  - Note experience depth (years) and breadth (variety of tasks)
  - Highlight relevant industry experience
  
  • Education Analysis
  Assess whether the candidate's educational background meets job requirements.
  - Evaluate degrees, certifications, and specialized training
  - Consider relevance of field of study to the position
  - Note any educational requirements stated in the job description not met by the candidate
  
  • Other Relevant Data Analysis
  Consider additional factors that might impact suitability.
  - Location compatibility
  - Language proficiency if mentioned
  - Specific certifications or clearances required
  - Cultural fit indicators if available
  
  ➔ Strengths
  List 3-5 specific, evidence-based strengths that make this candidate suitable for the position.
  - Each strength should reference specific examples from the CV
  - Focus on strengths that directly address job requirements
  
  ➔ Weaknesses
  List 2-4 specific gaps or weaknesses in the candidate's profile relative to the job.
  - Be precise about missing skills or experience
  - Avoid vague statements
  - Consider both stated and implied requirements
  
  ➔ Points Needing Clarification
  List 2-3 specific questions that should be addressed in an interview to better assess fit.
  - Focus on areas where the CV is ambiguous
  - Target potential skill gaps that need verification
  - Identify areas where more detail would help assess suitability
  
  ➔ Suitability Score
  Provide a numeric score (0-100) based on overall fit.
  - 90-100: Exceptional match with all or nearly all requirements met
  - 70-89: Strong match with most key requirements met
  - 50-69: Moderate match with some key requirements met but significant gaps
  - 30-49: Weak match with several key requirements missing
  - 0-29: Poor match with most key requirements missing
  
  EXAMPLE FORMAT:
  • Skills Analysis
  The candidate possesses a strong set of skills that align well with the job requirements. Key competencies include:
  - Power BI and SSAS: The candidate has extensive experience in developing reports and cubes using these tools, which are crucial for the role.
  - Data Warehousing and ETL: The ability to design data warehouses and create ETL processes with Talend is directly relevant to the job description.
  - Big Data Processing: Experience with Hadoop is mentioned, though it is less emphasized compared to other skills.
  - Project Management Tools: Familiarity with JIRA, Trello, and Agile methodologies matches the requirements listed in the job posting.
  Overall, most required skills are present in the CV.
  
  CV:
  ${cvText}
  
  Job Description:
  ${jobDescription}
  
  BE RIGOROUS, SPECIFIC, AND EVIDENCE-BASED IN YOUR ANALYSIS. FOLLOW THE FORMAT STRICTLY.
  `;
  
      // Call the Cohere API
      const response = await fetch("https://api.cohere.ai/v1/generate", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${apiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          prompt,
          model: settings.model,
          max_tokens: settings.maxTokens,
          temperature: settings.temperature,
          k: 0,
          stop_sequences: ["Human:", "AI:"],
          return_likelihoods: "NONE",
        }),
      });
  
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(`Cohere API error: ${errorData.message || response.statusText}`);
      }
  
      const data = await response.json();
      
      if (!data.generations || data.generations.length === 0) {
        throw new Error("No response from Cohere API");
      }
  
      // Parse the response
      const analysisText = data.generations[0].text;
      const analysisResult = parseAnalysisResponse(analysisText);
      
      // Add raw response for debugging or custom parsing if needed
      analysisResult.rawResponse = analysisText;
      
      return analysisResult;
    } catch (error) {
      console.error("Error in Cohere analysis:", error);
      throw error;
    }
  }
  
  /**
   * Generate a comprehensive recruiter report with additional insights
   * @param {string} cvText - The candidate's CV text
   * @param {string} jobDescription - The job description text
   * @param {string} apiKey - Your Cohere API key
   * @param {Object} options - Additional options
   * @returns {Promise<Object>} Complete analysis with enhanced report
   */
  async function generateRecruiterReport(cvText, jobDescription, apiKey, options = {}) {
    // First get the basic analysis
    const analysis = await analyzeMatch(cvText, jobDescription, apiKey, options);
    
    // Calculate additional metrics
    const skillMatchPercentage = analysis.skills && analysis.skills.items ? 
      Math.min(100, Math.round((analysis.skills.items.length / 10) * 100)) : 0;
    
    // Add interview recommendations based on strengths and weaknesses
    const interviewRecommendations = [];
    
    if (analysis.suitabilityScore >= 70) {
      interviewRecommendations.push("Proceed to technical interview");
      if (analysis.strengths.length >= 4) {
        interviewRecommendations.push("Consider fast-tracking this candidate");
      }
    } else if (analysis.suitabilityScore >= 50) {
      interviewRecommendations.push("Initial screening interview recommended");
      interviewRecommendations.push("Focus on addressing skill gaps");
    } else {
      interviewRecommendations.push("Consider for different position");
      interviewRecommendations.push("Not recommended for this role");
    }
    
    // Generate interview questions based on clarifications needed
    const interviewQuestions = analysis.clarifications.map(clarification => {
      // Convert clarification points into actual questions
      if (clarification.endsWith("?")) {
        return clarification;
      }
      // Try to convert statements into questions
      if (clarification.toLowerCase().startsWith("clarify")) {
        return clarification.replace(/^clarify/i, "Can you clarify") + "?";
      }
      return `Can you elaborate on ${clarification.toLowerCase()}?`;
    });
    
    // Add all enhancements to the final report
    const enhancedReport = {
      ...analysis,
      metrics: {
        skillMatchPercentage,
        strengthsCount: analysis.strengths.length,
        weaknessesCount: analysis.weaknesses.length,
        overallFitScore: analysis.suitabilityScore
      },
      recommendations: {
        interview: interviewRecommendations,
        questions: interviewQuestions,
        nextSteps: analysis.suitabilityScore >= 60 ? 
          ["Schedule technical interview", "Check references", "Conduct background verification"] : 
          ["Consider for other positions", "Keep resume on file"]
      }
    };
    
    return enhancedReport;
  }
  
  // Export the functions as a module for browsers
  const RecruiterAI = {
    analyzeMatch,
    generateRecruiterReport,
    parseAnalysisResponse
  };
  
  // Make it available both as a module and globally
  if (typeof window !== 'undefined') {
    // Browser environment
    window.RecruiterAI = RecruiterAI;
  }
  
  // For ES modules
  export { analyzeMatch, generateRecruiterReport, parseAnalysisResponse };
  export default RecruiterAI;