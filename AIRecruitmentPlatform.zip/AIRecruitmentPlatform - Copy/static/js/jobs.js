export function initJobListings() {
    const searchInput = document.getElementById('job-search');
    const categoryFilter = document.getElementById('job-filter-category');
    const salaryFilter = document.getElementById('job-filter-salary');
    const typeFilter = document.getElementById('job-filter-type');
    const locationFilter = document.getElementById('job-filter-location');

    // Add event listeners to all filter elements
    searchInput.addEventListener('input', filterJobs);
    categoryFilter.addEventListener('change', filterJobs);
    salaryFilter.addEventListener('change', filterJobs);
    typeFilter.addEventListener('change', filterJobs);
    locationFilter.addEventListener('change', filterJobs);

    // Initial filtering on page load
    filterJobs();

    /**
     * Filters job listings based on all criteria
     */
    function filterJobs() {
        // Show the loader before starting the filtering process
        toggleLoader(true);

        try {
            const searchTerm = searchInput.value.toLowerCase();
            const categoryValue = categoryFilter.value;
            const salaryValue = salaryFilter.value;
            const typeValue = typeFilter.value;
            const locationValue = locationFilter.value;

            const jobCards = document.querySelectorAll('.job-card');

            jobCards.forEach(card => {
                // Extract all needed data from the job card
                const title = card.querySelector('.job-title').textContent.toLowerCase();
                const description = card.querySelector('.job-description')?.textContent.toLowerCase() || '';
                const category = card.getAttribute('data-category');

                // Extract additional data from badges
                const badges = card.querySelectorAll('.badge');
                let location = '';
                let jobType = '';

                badges.forEach(badge => {
                    const text = badge.textContent.toLowerCase();
                    // This assumes the order of badges matches the HTML structure
                    // For more reliable filtering, consider adding data attributes to each badge
                    if (!jobType && typeValue !== 'all' && text.includes(typeValue.toLowerCase())) {
                        jobType = text;
                    }
                    if (!location && locationValue !== 'all' && text.includes(locationValue.toLowerCase())) {
                        location = text;
                    }
                });

                // Check if job meets all filter criteria
                const matchesSearch = title.includes(searchTerm) || description.includes(searchTerm);
                const matchesCategory = categoryValue === 'all' || category === categoryValue;
                const matchesSalary = salaryValue === 'all'; // Assuming salary isn't directly visible in the card
                const matchesType = typeValue === 'all' || jobType !== '';
                const matchesLocation = locationValue === 'all' || location !== '';

                // Show or hide based on all criteria
                card.style.display = (matchesSearch && matchesCategory &&
                                    matchesSalary && matchesType && matchesLocation) ? 'block' : 'none';
            });

            // Check if we need to show a "no results" message
            checkNoResults(jobCards);
        } catch (error) {
            console.error("Error filtering jobs:", error);
        } finally {
            // Hide the loader after filtering is complete
            setTimeout(() => toggleLoader(false), 300); // Small delay for smoother UX
        }
    }

    /**
     * Checks if there are any visible job cards and displays a message if none
     * @param {NodeList} jobCards - The collection of job cards
     */
    function checkNoResults(jobCards) {
        const visibleJobs = Array.from(jobCards).filter(job => job.style.display !== 'none');
        let noResultsMessage = document.getElementById('no-results-message');

        if (visibleJobs.length === 0) {
            if (!noResultsMessage) {
                // Create a message if it doesn't exist
                noResultsMessage = document.createElement('div');
                noResultsMessage.id = 'no-results-message';
                noResultsMessage.className = 'alert alert-info mt-4';
                noResultsMessage.textContent = 'No jobs match your current filters. Try adjusting your search criteria.';

                const jobListings = document.getElementById('job-listings');
                jobListings.appendChild(noResultsMessage);
            } else {
                noResultsMessage.style.display = 'block';
            }
        } else if (noResultsMessage) {
            noResultsMessage.style.display = 'none';
        }
    }
}
