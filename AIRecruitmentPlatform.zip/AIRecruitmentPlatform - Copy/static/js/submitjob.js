export function applyForJob(jobId) {
    // Store the job ID in session storage before redirecting to assessment
    sessionStorage.setItem('currentJobApplication', jobId);
    window.location.href = `/submitjob/${jobId}`;
}

