"""
Email Service Module for TechInterview Platform using SendGrid
"""
import os
import sys
import logging
from flask import current_app
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail, Email, To, Content
from datetime import datetime

logger = logging.getLogger(__name__)

def init_app(app):
    """
    Initialize the email service with the Flask app
    """
    # Set SendGrid config
    app.config['SENDGRID_API_KEY'] = os.environ.get('SENDGRID_API_KEY')
    app.config['MAIL_DEFAULT_SENDER'] = os.environ.get('MAIL_DEFAULT_SENDER', 'techinterview@example.com')
    
    # Check if SendGrid API key is configured
    if not app.config['SENDGRID_API_KEY']:
        logger.warning("SendGrid API key not configured. Email functionality will be limited.")
    
    logger.info("Email service initialized")


def send_email(subject, recipients, text_body, html_body=None, sender=None):
    """
    Send an email using SendGrid
    
    Args:
        subject (str): Email subject
        recipients (list): List of recipient email addresses
        text_body (str): Text version of the email body
        html_body (str): HTML version of the email body (optional)
        sender (str): Sender email address (optional, uses default if not provided)
    
    Returns:
        bool: Success status
    """
    if not isinstance(recipients, list):
        recipients = [recipients]
    
    # Get API key from app config
    sendgrid_api_key = current_app.config.get('SENDGRID_API_KEY')
    if not sendgrid_api_key:
        logger.error("SendGrid API key not configured")
        return False
    
    from_email = sender or current_app.config.get('MAIL_DEFAULT_SENDER')
    
    # Loop through recipients and send individual emails (SendGrid recommendation)
    success = True
    for recipient in recipients:
        message = Mail(
            from_email=Email(from_email),
            to_emails=To(recipient),
            subject=subject
        )
        
        if html_body:
            message.content = Content("text/html", html_body)
        else:
            message.content = Content("text/plain", text_body)
        
        try:
            sg = SendGridAPIClient(sendgrid_api_key)
            response = sg.send(message)
            logger.info(f"Email sent to {recipient}, status code: {response.status_code}")
        except Exception as e:
            logger.error(f"Failed to send email to {recipient}: {str(e)}")
            success = False
    
    return success


def send_interview_invitation(interview, participant_email):
    """
    Send an interview invitation email
    
    Args:
        interview: Interview model instance
        participant_email (str): Email address of the participant
    
    Returns:
        bool: Success status
    """
    subject = f"Invitation: Technical Interview - {interview['title']}"
    
    text_body = f"""
    You have been invited to a technical interview!
    
    Title: {interview['title']}
    Description: {interview.get('description', 'No description provided')}
    Scheduled Time: {datetime.fromisoformat(interview['scheduled_time']).strftime('%Y-%m-%d %H:%M')}
    Duration: {interview['duration']} minutes
    
    To join the interview, please click on the following link:
   {current_app.config.get('BASE_URL', '')}interview/{interview['room_code']}
    
    A video call will be available when you join the interview session.
    
    Thank you,
    TechInterview Platform
    """
    
    html_body = f"""
    <h2>You have been invited to a technical interview!</h2>
    
    <p><strong>Title:</strong> {interview['title']}</p>
    <p><strong>Description:</strong> {interview.get('description', 'No description provided')}</p>
    <p><strong>Scheduled Time:</strong> {datetime.fromisoformat(interview['scheduled_time']).strftime('%Y-%m-%d %H:%M')}</p>
    <p><strong>Duration:</strong> {interview['duration']} minutes</p>
    
    <p>To join the interview, please click on the following link:<br>
    <a href="{current_app.config.get('BASE_URL', '')}interview/{interview['room_code']}">Join Interview Session</a></p>
    
    <p>A video call will be available when you join the interview session.</p>
    
    <p>Thank you,<br>
    TechInterview Platform</p>
    """
    
    return send_email(
        subject=subject,
        recipients=[participant_email],
        text_body=text_body,
        html_body=html_body
    )


def send_interview_reminder(interview):
    """
    Send a reminder email for an upcoming interview
    
    Args:
        interview: Interview model instance
    
    Returns:
        bool: Success status
    """
    # Get emails for both creator and participant
    recipients = []
    if interview.creator and interview.creator.email:
        recipients.append(interview.creator.email)
    if interview.participant and interview.participant.email:
        recipients.append(interview.participant.email)
    elif interview.participant_email:
        recipients.append(interview.participant_email)
    
    if not recipients:
        logger.warning(f"No recipients found for interview reminder (ID: {interview.id})")
        return False
    
    subject = f"Reminder: Technical Interview - {interview.title}"
    
    text_body = f"""
    Reminder: You have a technical interview scheduled soon!
    
    Title: {interview.title}
    Description: {interview.description or 'No description provided'}
    Scheduled Time: {interview.scheduled_time.strftime('%Y-%m-%d %H:%M')}
    Duration: {interview.duration} minutes
    
    To join the interview, please click on the following link:
    {current_app.config.get('BASE_URL', '')}interview/{interview.room_code}
    
    A video call will be available when you join the interview session.
    
    Thank you,
    TechInterview Platform
    """
    
    html_body = f"""
    <h2>Reminder: You have a technical interview scheduled soon!</h2>
    
    <p><strong>Title:</strong> {interview.title}</p>
    <p><strong>Description:</strong> {interview.description or 'No description provided'}</p>
    <p><strong>Scheduled Time:</strong> {interview.scheduled_time.strftime('%Y-%m-%d %H:%M')}</p>
    <p><strong>Duration:</strong> {interview.duration} minutes</p>
    
    <p>To join the interview, please click on the following link:<br>
    <a href="{current_app.config.get('BASE_URL', '')}interview/{interview.room_code}">Join Interview Session</a></p>
    
    <p>A video call will be available when you join the interview session.</p>
    
    <p>Thank you,<br>
    TechInterview Platform</p>
    """
    
    return send_email(
        subject=subject,
        recipients=recipients,
        text_body=text_body,
        html_body=html_body
    )


def send_code_snapshot(interview, code_content, recipient_email):
    """
    Send a code snapshot from an interview session
    
    Args:
        interview: Interview model instance
        code_content (str): The code to send
        recipient_email (str): Email address of the recipient
    
    Returns:
        bool: Success status
    """
    subject = f"Code Snapshot from Interview: {interview.title}"
    
    text_body = f"""
    Here is the code snapshot from the interview: {interview.title}
    
    Language: {interview.language}
    Time: {interview.scheduled_time.strftime('%Y-%m-%d %H:%M')}
    
    CODE:
    {code_content}
    
    To access the interview again, please click on the following link:
    {current_app.config.get('BASE_URL', '')}interview/{interview.room_code}
    
    Thank you,
    TechInterview Platform
    """
    
    html_body = f"""
    <h2>Code Snapshot from Interview: {interview.title}</h2>
    
    <p><strong>Language:</strong> {interview.language}</p>
    <p><strong>Time:</strong> {interview.scheduled_time.strftime('%Y-%m-%d %H:%M')}</p>
    
    <h3>Code:</h3>
    <pre style="background-color: #f5f5f5; padding: 15px; border-radius: 5px; overflow-x: auto;">
    <code>{code_content}</code>
    </pre>
    
    <p>To access the interview again, please click on the following link:<br>
    <a href="{current_app.config.get('BASE_URL', '')}interview/{interview.room_code}">Return to Interview Session</a></p>
    
    <p>Thank you,<br>
    TechInterview Platform</p>
    """
    
    return send_email(
        subject=subject,
        recipients=[recipient_email],
        text_body=text_body,
        html_body=html_body
    )
    
    ###"brevo api key =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"