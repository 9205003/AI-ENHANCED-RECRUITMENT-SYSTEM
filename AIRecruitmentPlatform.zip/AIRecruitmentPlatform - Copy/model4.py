import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
import spacy
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import re

# Load NLP model for advanced text processing
nlp = spacy.load("en_core_web_sm")

# Define comprehensive scoring weights for different criteria
SCORING_WEIGHTS = {
    "technical_skills": 0.30,      # Programming, data analysis, project management
    "education": 0.15,             # Degrees, certifications, field of study
    "experience": 0.20,            # Work history, responsibilities, industry knowledge
    "soft_skills": 0.20,           # Communication, teamwork, problem-solving
    "cultural_fit": 0.10,          # Values alignment, work environment preferences
    "portfolio": 0.05              # Projects, professional presence
}

# Sub-weights for more granular scoring
SUB_WEIGHTS = {
    "technical_skills": {
        "primarySkills": 0.40,
        "skillProgramming": 0.25,
        "skillDataAnalysis": 0.20,
        "skillProjectMgmt": 0.15
    },
    "soft_skills": {
        "communication": 0.35,
        "teamwork": 0.35,
        "problem_solving": 0.30
    },
    "communication": {
        "presentation_exp": 0.30,
        "verbal_communication": 0.35,
        "written_communication": 0.35
    },
    "problem_solving": {
        "learningApproach": 0.50,
        "problemSolvingTechnique": 0.50
    },
    "cultural_fit": {
        "challenges": 0.30,
        "workEnvironment": 0.35,
        "workplaceValues": 0.35
    },
    "education": {
        "highestDegree": 0.40,
        "fieldOfStudy": 0.30,
        "certifications": 0.20,
        "institution": 0.10
    },
    "experience": {
        "yearsExperience": 0.25,
        "responsibilities": 0.30,
        "industry": 0.20,
        "currentRole": 0.15,
        "currentCompany": 0.10
    },
    "portfolio": {
        "proudProject": 0.50,
        "professionalProfile": 0.30,
        "portfolioUrl": 0.20
    }
}

class SkillExtractor:
    """Extract and analyze skills from text using NLP techniques."""
    
    def __init__(self):
        self.vectorizer = TfidfVectorizer(stop_words='english')
        self.skill_patterns = {
            'technical': [
                r'\b(python|java|javascript|html|css|react|angular|vue|node\.js|sql|nosql|mongodb|aws|azure|gcp|docker|kubernetes|machine learning|ai|data science|tableau|power bi|excel|word|powerpoint|photoshop|illustrator|indesign)\b',
                r'\b(frontend|backend|full[-\s]?stack|web development|mobile development|ios|android|flutter|react native|devops|cloud|database|networking|security|blockchain)\b'
            ],
            'soft': [
                r'\b(communication|teamwork|leadership|time[-\s]?management|problem[-\s]?solving|critical thinking|creativity|adaptability|flexibility|organization|detail[-\s]?oriented|multitasking)\b',
                r'\b(collaboration|presentation|negotiation|conflict resolution|emotional intelligence|customer service|project management|decision[-\s]?making|stress management)\b'
            ]
        }
    
    def extract_skills_from_text(self, text, skill_type='all'):
        """Extract skills from text using regex patterns and NLP."""
        if not text:
            return set()
            
        text = text.lower()
        doc = nlp(text)
        
        # Extract skills using NLP
        skills = set()
        for chunk in doc.noun_chunks:
            if len(chunk.text.split()) <= 3:  # Limit to reasonable skill phrases
                skills.add(chunk.text)
        
        # Add skills from regex patterns
        if skill_type in ['technical', 'all']:
            for pattern in self.skill_patterns['technical']:
                skills.update(re.findall(pattern, text.lower()))
                
        if skill_type in ['soft', 'all']:
            for pattern in self.skill_patterns['soft']:
                skills.update(re.findall(pattern, text.lower()))
        
        # Clean skills
        cleaned_skills = {skill.strip() for skill in skills if len(skill.strip()) > 2}
        return cleaned_skills
    
    def calculate_text_similarity(self, text1, text2):
        """Calculate semantic similarity between two text snippets."""
        if not text1 or not text2:
            return 0.0
            
        # Create TF-IDF vectors
        try:
            tfidf_matrix = self.vectorizer.fit_transform([text1, text2])
            # Calculate cosine similarity
            similarity = cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:2])[0][0]
            return similarity
        except:
            # Fallback to simpler comparison if vectorization fails
            text1_set = set(text1.lower().split())
            text2_set = set(text2.lower().split())
            if not text1_set or not text2_set:
                return 0.0
            return len(text1_set.intersection(text2_set)) / len(text1_set.union(text2_set))

    def match_skills(self, candidate_skills, job_skills):
        """Calculate match percentage between candidate and job skills."""
        if not job_skills:
            return 0.0
            
        matched_skills = candidate_skills.intersection(job_skills)
        return len(matched_skills) / len(job_skills) * 100

class ApplicantEvaluator:
    """Evaluate applicants based on job requirements and applicant data."""
    
    def __init__(self):
        self.skill_extractor = SkillExtractor()
        self.scaler = MinMaxScaler(feature_range=(0, 100))
    
    def parse_job_description(self, job_description):
        """Parse job description to extract requirements."""
        doc = nlp(job_description)
        
        requirements = {
            "technical_skills": self.skill_extractor.extract_skills_from_text(job_description, 'technical'),
            "soft_skills": self.skill_extractor.extract_skills_from_text(job_description, 'soft'),
            "education": [],
            "experience": [],
            "cultural_values": []
        }
        
        # Extract education requirements
        education_section = re.search(r'education:?(.*?)(?:\n\n|\Z)', job_description, re.IGNORECASE | re.DOTALL)
        if education_section:
            requirements["education"] = education_section.group(1).strip()
            
        # Extract experience requirements
        experience_section = re.search(r'experience:?(.*?)(?:\n\n|\Z)', job_description, re.IGNORECASE | re.DOTALL)
        if experience_section:
            requirements["experience"] = experience_section.group(1).strip()
            
        # Extract cultural values/requirements
        culture_section = re.search(r'(culture|values|environment):?(.*?)(?:\n\n|\Z)', job_description, re.IGNORECASE | re.DOTALL)
        if culture_section:
            requirements["cultural_values"] = culture_section.group(2).strip()
        
        return requirements
    
    def evaluate_technical_skills(self, applicant_data, job_requirements):
        """Evaluate technical skills match."""
        scores = {}
        
        # Primary skills evaluation
        primary_skills = set(applicant_data.get("technical_skills", {}).get("primarySkills", []))
        primary_skills_score = self.skill_extractor.match_skills(primary_skills, job_requirements["technical_skills"])
        scores["primarySkills"] = primary_skills_score
        
        # Programming skills evaluation
        programming_skills = set(applicant_data.get("technical_skills", {}).get("skillProgramming", []))
        programming_score = self.skill_extractor.match_skills(programming_skills, job_requirements["technical_skills"])
        scores["skillProgramming"] = programming_score
        
        # Data analysis skills evaluation
        data_analysis_skills = set(applicant_data.get("technical_skills", {}).get("skillDataAnalysis", []))
        data_analysis_score = self.skill_extractor.match_skills(data_analysis_skills, job_requirements["technical_skills"])
        scores["skillDataAnalysis"] = data_analysis_score
        
        # Project management skills evaluation
        project_mgmt_skills = set(applicant_data.get("technical_skills", {}).get("skillProjectMgmt", []))
        project_mgmt_score = self.skill_extractor.match_skills(project_mgmt_skills, job_requirements["technical_skills"])
        scores["skillProjectMgmt"] = project_mgmt_score
        
        # Calculate weighted technical skills score
        weighted_score = 0
        for key, score in scores.items():
            weighted_score += score * SUB_WEIGHTS["technical_skills"].get(key, 0)
        
        return scores, weighted_score
    
    def evaluate_soft_skills(self, applicant_data, job_requirements):
        """Evaluate soft skills match."""
        scores = {}
        
        # Communication skills evaluation
        comm_data = applicant_data.get("communication", {})
        comm_text = f"{comm_data.get('presentation_exp', '')} {comm_data.get('verbal_communication', '')} {comm_data.get('written_communication', '')}"
        comm_skills = self.skill_extractor.extract_skills_from_text(comm_text, 'soft')
        comm_score = self.skill_extractor.match_skills(comm_skills, job_requirements["soft_skills"])
        scores["communication"] = comm_score
        
        # Teamwork evaluation
        teamwork = applicant_data.get("personality", {}).get("teamwork", "")
        teamwork_skills = self.skill_extractor.extract_skills_from_text(teamwork, 'soft')
        teamwork_score = self.skill_extractor.match_skills(teamwork_skills, job_requirements["soft_skills"])
        scores["teamwork"] = teamwork_score
        
        # Problem-solving evaluation
        problem_solving_data = applicant_data.get("problem_solving", {})
        problem_solving_text = f"{problem_solving_data.get('learningApproach', '')} {problem_solving_data.get('problemSolvingTechnique', '')}"
        problem_solving_skills = self.skill_extractor.extract_skills_from_text(problem_solving_text, 'soft')
        problem_solving_score = self.skill_extractor.match_skills(problem_solving_skills, job_requirements["soft_skills"])
        scores["problem_solving"] = problem_solving_score
        
        # Calculate weighted soft skills score
        weighted_score = 0
        for key, score in scores.items():
            weighted_score += score * SUB_WEIGHTS["soft_skills"].get(key, 0)
        
        return scores, weighted_score
    
    def evaluate_education(self, applicant_data, job_requirements):
        """Evaluate education qualifications."""
        scores = {}
        edu_data = applicant_data.get("education", {})
        
        # If there's a text description of education requirements
        if isinstance(job_requirements["education"], str) and job_requirements["education"]:
            # Highest degree evaluation
            degree = edu_data.get("highestDegree", "")
            degree_match = 0
            if degree and re.search(rf'\b{re.escape(degree)}\b', job_requirements["education"], re.IGNORECASE):
                degree_match = 100
            elif degree:
                # Partial match based on degree level
                degree_levels = {"bachelor": 1, "master": 2, "phd": 3, "doctorate": 3}
                job_degree_level = 0
                for level in degree_levels:
                    if level in job_requirements["education"].lower():
                        job_degree_level = degree_levels[level]
                        break
                
                applicant_degree_level = 0
                for level in degree_levels:
                    if level in degree.lower():
                        applicant_degree_level = degree_levels[level]
                        break
                
                if applicant_degree_level >= job_degree_level and job_degree_level > 0:
                    degree_match = 100
                elif applicant_degree_level > 0 and job_degree_level > 0:
                    degree_match = (applicant_degree_level / job_degree_level) * 100
            
            scores["highestDegree"] = degree_match
            
            # Field of study evaluation
            field = edu_data.get("fieldOfStudy", "")
            field_match = 0
            if field and field.lower() in job_requirements["education"].lower():
                field_match = 100
            elif field:
                field_match = self.skill_extractor.calculate_text_similarity(field, job_requirements["education"]) * 100
            
            scores["fieldOfStudy"] = field_match
            
            # Certifications evaluation
            certifications = edu_data.get("certifications", [])
            cert_match = 0
            if certifications:
                cert_text = " ".join(certifications)
                cert_match = self.skill_extractor.calculate_text_similarity(cert_text, job_requirements["education"]) * 100
            
            scores["certifications"] = cert_match
            
            # Institution evaluation (less weight)
            institution = edu_data.get("institution", "")
            inst_match = 0
            if institution and institution.lower() in job_requirements["education"].lower():
                inst_match = 100
            
            scores["institution"] = inst_match
        else:
            # Default scores if no specific requirements
            scores = {
                "highestDegree": 50,  # Neutral score
                "fieldOfStudy": 50,
                "certifications": 50,
                "institution": 50
            }
        
        # Calculate weighted education score
        weighted_score = 0
        for key, score in scores.items():
            weighted_score += score * SUB_WEIGHTS["education"].get(key, 0)
        
        return scores, weighted_score
    
    def evaluate_experience(self, applicant_data, job_requirements):
        """Evaluate work experience."""
        scores = {}
        exp_data = applicant_data.get("experience", {})
        
        # If there's a text description of experience requirements
        if isinstance(job_requirements["experience"], str) and job_requirements["experience"]:
            # Years of experience evaluation
            years_exp = exp_data.get("yearsExperience", 0)
            required_years = 0
            years_match = re.search(r'(\d+)[\+]?\s+years?', job_requirements["experience"])
            if years_match:
                required_years = int(years_match.group(1))
            
            years_score = 0
            if required_years > 0:
                years_score = min(100, (years_exp / required_years) * 100)
            elif years_exp > 0:  # No specific requirement but has experience
                years_score = 100
            
            scores["yearsExperience"] = years_score
            
            # Responsibilities evaluation
            responsibilities = exp_data.get("responsibilities", "")
            resp_score = 0
            if responsibilities:
                resp_score = self.skill_extractor.calculate_text_similarity(responsibilities, job_requirements["experience"]) * 100
            
            scores["responsibilities"] = resp_score
            
            # Industry match
            industry = exp_data.get("industry", "")
            industry_score = 0
            if industry and industry.lower() in job_requirements["experience"].lower():
                industry_score = 100
            elif industry:
                industry_score = self.skill_extractor.calculate_text_similarity(industry, job_requirements["experience"]) * 100
            
            scores["industry"] = industry_score
            
            # Current role relevance
            current_role = exp_data.get("currentRole", "")
            role_score = 0
            if current_role:
                role_score = self.skill_extractor.calculate_text_similarity(current_role, job_requirements["experience"]) * 100
            
            scores["currentRole"] = role_score
            
            # Company relevance (least weight)
            current_company = exp_data.get("currentCompany", "")
            company_score = 0
            if current_company and current_company.lower() in job_requirements["experience"].lower():
                company_score = 100
            
            scores["currentCompany"] = company_score
        else:
            # Default scores if no specific requirements
            scores = {
                "yearsExperience": 50,
                "responsibilities": 50,
                "industry": 50,
                "currentRole": 50,
                "currentCompany": 50
            }
        
        # Calculate weighted experience score
        weighted_score = 0
        for key, score in scores.items():
            weighted_score += score * SUB_WEIGHTS["experience"].get(key, 0)
        
        return scores, weighted_score
    
    def evaluate_cultural_fit(self, applicant_data, job_requirements):
        """Evaluate cultural fit."""
        scores = {}
        cultural_data = applicant_data.get("cultural_test", {})
        
        # If there's a text description of cultural values
        if isinstance(job_requirements["cultural_values"], str) and job_requirements["cultural_values"]:
            # Work challenges alignment
            challenges = cultural_data.get("challenges", "")
            challenges_score = 0
            if challenges:
                challenges_score = self.skill_extractor.calculate_text_similarity(challenges, job_requirements["cultural_values"]) * 100
            
            scores["challenges"] = challenges_score
            
            # Work environment preferences
            environment = cultural_data.get("workEnvironment", "")
            environment_score = 0
            if environment:
                environment_score = self.skill_extractor.calculate_text_similarity(environment, job_requirements["cultural_values"]) * 100
            
            scores["workEnvironment"] = environment_score
            
            # Workplace values alignment
            values = cultural_data.get("workplaceValues", "")
            values_score = 0
            if values:
                values_score = self.skill_extractor.calculate_text_similarity(values, job_requirements["cultural_values"]) * 100
            
            scores["workplaceValues"] = values_score
        else:
            # Extract personality traits for cultural fit
            personality = applicant_data.get("personality", {})
            ambiguity = personality.get("ambiguity", "")
            innovation = personality.get("innovation", "")
            
            # Default scores based on personality if no specific requirements
            scores = {
                "challenges": 50,
                "workEnvironment": 50,
                "workplaceValues": 50
            }
            
            # Adjust based on personality if available
            if ambiguity or innovation:
                scores["challenges"] = 60
                scores["workEnvironment"] = 60
        
        # Calculate weighted cultural fit score
        weighted_score = 0
        for key, score in scores.items():
            weighted_score += score * SUB_WEIGHTS["cultural_fit"].get(key, 0)
        
        return scores, weighted_score
    
    def evaluate_portfolio(self, applicant_data, job_requirements):
        """Evaluate portfolio and projects."""
        scores = {}
        portfolio_data = applicant_data.get("portfolio", {})
        
        # Proud project evaluation
        proud_project = portfolio_data.get("proudProject", "")
        project_score = 0
        if proud_project:
            # Extract skills from project description
            project_skills = self.skill_extractor.extract_skills_from_text(proud_project)
            technical_match = self.skill_extractor.match_skills(project_skills, job_requirements["technical_skills"])
            soft_match = self.skill_extractor.match_skills(project_skills, job_requirements["soft_skills"])
            project_score = (technical_match * 0.7) + (soft_match * 0.3)
        
        scores["proudProject"] = project_score
        
        # Professional profile evaluation
        profile = portfolio_data.get("professionalProfile", "")
        profile_score = 0
        if profile:
            # Calculate similarity to job requirements
            tech_sim = self.skill_extractor.calculate_text_similarity(profile, " ".join(job_requirements["technical_skills"]))
            soft_sim = self.skill_extractor.calculate_text_similarity(profile, " ".join(job_requirements["soft_skills"]))
            profile_score = ((tech_sim * 0.7) + (soft_sim * 0.3)) * 100
        
        scores["professionalProfile"] = profile_score
        
        # Portfolio URL presence (binary score)
        portfolio_url = portfolio_data.get("portfolioUrl", "")
        url_score = 100 if portfolio_url else 0
        scores["portfolioUrl"] = url_score
        
        # Calculate weighted portfolio score
        weighted_score = 0
        for key, score in scores.items():
            weighted_score += score * SUB_WEIGHTS["portfolio"].get(key, 0)
        
        return scores, weighted_score
    
    def evaluate_applicant(self, applicant_data, job_description):
        """Comprehensive evaluation of an applicant for a job."""
        # Parse job requirements
        job_requirements = self.parse_job_description(job_description)
        
        # Evaluate each category
        technical_scores, technical_weighted = self.evaluate_technical_skills(applicant_data, job_requirements)
        soft_skill_scores, soft_skill_weighted = self.evaluate_soft_skills(applicant_data, job_requirements)
        education_scores, education_weighted = self.evaluate_education(applicant_data, job_requirements)
        experience_scores, experience_weighted = self.evaluate_experience(applicant_data, job_requirements)
        cultural_scores, cultural_weighted = self.evaluate_cultural_fit(applicant_data, job_requirements)
        portfolio_scores, portfolio_weighted = self.evaluate_portfolio(applicant_data, job_requirements)
        
        # Calculate category scores
        category_scores = {
            "technical_skills": technical_weighted,
            "soft_skills": soft_skill_weighted,
            "education": education_weighted,
            "experience": experience_weighted,
            "cultural_fit": cultural_weighted,
            "portfolio": portfolio_weighted
        }
        
        # Calculate final weighted score
        final_score = 0
        for category, score in category_scores.items():
            final_score += score * SCORING_WEIGHTS.get(category, 0)
        
        # Prepare detailed report
        detailed_scores = {
            "technical_skills": {
                "score": technical_weighted,
                "breakdown": technical_scores,
                "weight": SCORING_WEIGHTS["technical_skills"]
            },
            "soft_skills": {
                "score": soft_skill_weighted,
                "breakdown": soft_skill_scores,
                "weight": SCORING_WEIGHTS["soft_skills"]
            },
            "education": {
                "score": education_weighted,
                "breakdown": education_scores,
                "weight": SCORING_WEIGHTS["education"]
            },
            "experience": {
                "score": experience_weighted,
                "breakdown": experience_scores,
                "weight": SCORING_WEIGHTS["experience"]
            },
            "cultural_fit": {
                "score": cultural_weighted,
                "breakdown": cultural_scores,
                "weight": SCORING_WEIGHTS["cultural_fit"]
            },
            "portfolio": {
                "score": portfolio_weighted,
                "breakdown": portfolio_scores,
                "weight": SCORING_WEIGHTS["portfolio"]
            },
            "final_score": final_score
        }
        
        return detailed_scores

def generate_applicant_insights(evaluation_results):
    """Generate human-readable insights from evaluation results."""
    final_score = evaluation_results["final_score"]
    
    insights = {
        "summary": f"Overall fit score: {final_score:.2f}/100",
        "strengths": [],
        "areas_for_improvement": [],
        "match_status": ""
    }
    
    # Determine overall match status
    if final_score >= 85:
        insights["match_status"] = "Excellent Match"
    elif final_score >= 70:
        insights["match_status"] = "Strong Match"
    elif final_score >= 50:
        insights["match_status"] = "Potential Match"
    else:
        insights["match_status"] = "Weak Match"
    
    # Identify strengths (top 3 categories)
    categories = [(k, v["score"]) for k, v in evaluation_results.items() if k != "final_score"]
    strengths = sorted(categories, key=lambda x: x[1], reverse=True)[:3]
    
    for category, score in strengths:
        if score >= 70:  # Only include as strength if score is good
            category_name = category.replace("_", " ").title()
            insights["strengths"].append(f"{category_name} ({score:.2f}/100)")
    
    # Identify areas for improvement (bottom 2 categories)
    weaknesses = sorted(categories, key=lambda x: x[1])[:2]
    
    for category, score in weaknesses:
        if score < 70:  # Only include as weakness if score needs improvement
            category_name = category.replace("_", " ").title()
            insights["areas_for_improvement"].append(f"{category_name} ({score:.2f}/100)")
    
    return insights

# Example usage
def main():
    # Example job description
    job_description = """
    Senior Frontend Developer
    
    We are looking for a Senior Frontend Developer with expertise in React, JavaScript, HTML, CSS, and modern frontend frameworks.
    
    Technical Skills:
    - React JavaScript HTML ,CSS
     -skillDataAnalysis Google Analytics   A/B Testing ,
     -skillProgramming TypeScript Node.js GraphQL
     -skillProjectMgmt  Jira Agile Scrum
    
    Experience:
    - 5+ years of frontend development experience
    - Experience with Agile methodologies
    - Experience leading small teams and mentoring junior developers
    
    Education:
    - Bachelor's degree in Computer Science or related field
    - Frontend certifications are a plus
    -Meta React Developer
    
    Culture:
    - Collaborative team player
    - Problem solver who can work independently
    - Innovation-focused and willing to learn new technologies
    - Values open communication and transparency
    -Enjoy solving complex technical challenges and optimizing performance
    """
    
    # Example applicant data with comprehensive structure
    applicant_data = {
        "communication": {
            "presentation_exp": "Presented at 3 company-wide tech talks on React optimization",
            "verbal_communication": "Excellent verbal communication skills with clients and team members",
            "written_communication": "Created technical documentation and API guides"
        },
        "cultural_test": {
            "challenges": "Enjoy solving complex technical challenges and optimizing performance",
            "workEnvironment": "Thrive in collaborative environments with clear goals",
            "workplaceValues": "Value transparency, continuous learning, and mutual respect"
        },
        "education": {
            "certifications": ["AWS Certified Developer", "Meta React Developer","frontend certification"],
            "fieldOfStudy": "Computer Science",
            "highestDegree": "Bachelor's",
            "institution": "University of California"
        },
        "experience": {
            "currentCompany": "TechCorp Inc",
            "currentRole": "Frontend Developer",
            "industry": "E-commerce",
            "responsibilities": "Building responsive React applications, improving performance, implementing design systems",
            "yearsExperience": 4
        },
        "final_statement": {
            "availabilityDate": "2023-04-01",
            "positionInterest": "Excited about the opportunity to work on challenging projects",
            "salaryExpectations": "90,000-110,000"
        },
        "personality": {
            "ambiguity": "Comfortable with changing requirements",
            "innovation": "Constantly exploring new technologies and approaches",
            "teamwork": "Strong team player who enjoys collaboration and knowledge sharing"
        },
        "portfolio": {
            "portfolioUrl": "https://portfolio.example.com",
            "professionalProfile": "Frontend developer specializing in React, Redux, and modern JavaScript",
            "proudProject": "Built a high-performance e-commerce platform using React, Redux, and GraphQL that improved conversion rates by 15%"
        },
        "problem_solving": {
            "learningApproach": "Self-directed learner who stays updated with latest frontend technologies",
            "problemSolvingTechnique": "Break down complex problems, research solutions, implement iteratively"
        },
        "technical_skills": {
            "primarySkills": "efficient in React JavaScript HTML ,CSS",
            "skillDataAnalysis":  " familiar with Google Analytics A/B Testing",
            "skillProgramming": " done a number of projects in TypeScript Node.js GraphQL",
            "skillProjectMgmt": "Jira and AgileScrum"
        }
    }
    
    # Create evaluator and process the applicant
    evaluator = ApplicantEvaluator()
    evaluation_results = evaluator.evaluate_applicant(applicant_data, job_description)
    
    # Generate insights
    insights = generate_applicant_insights(evaluation_results)
    
    # Print results
    print("\n=== APPLICANT EVALUATION REPORT ===")
    print(f"\nFINAL SCORE: {evaluation_results['final_score']:.2f}/100")
    print(f"MATCH STATUS: {insights['match_status']}")
    
    print("\nCATEGORY SCORES:")
    for category, details in evaluation_results.items():
        if category != "final_score":
            print(f"- {category.replace('_', ' ').title()}: {details['score']:.2f}/100 (Weight: {details['weight']*100:.0f}%)")
    
    print("\nSTRENGTHS:")
    for strength in insights["strengths"]:
        print(f"- {strength}")
    
    print("\nAREAS FOR IMPROVEMENT:")
    for area in insights["areas_for_improvement"]:
        print(f"- {area}")
    
    print("\nDETAILED BREAKDOWN:")
    for category, details in evaluation_results.items():
        if category != "final_score":
            print(f"\n{category.replace('_', ' ').upper()}:")
            for subcategory, score in details.get("breakdown", {}).items():
                print(f"- {subcategory}: {score:.2f}/100")

if __name__ == "__main__":
    main()