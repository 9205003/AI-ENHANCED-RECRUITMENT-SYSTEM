from datetime import datetime
from firebase_admin import db

class AssessmentStage:
    TECHNICAL = 'technical'
    EXPERIENCE = 'experience'
    EDUCATION = 'education'
    CULTURAL = 'cultural'
    SOFT_SKILLS = 'soft_skills'
    INTERVIEW = 'interview'
    REFERENCES = 'references'
    BACKGROUND = 'background'
    PORTFOLIO = 'portfolio'

class Assessment:
    def __init__(self, application_id):
        self.application_id = application_id
        self.stages = {
            AssessmentStage.TECHNICAL: {
                'completed': False,
                'score': 0,
                'data': {},
                'feedback': ''
            },
            AssessmentStage.EXPERIENCE: {
                'completed': False,
                'score': 0,
                'data': {},
                'feedback': ''
            },
            AssessmentStage.EDUCATION: {
                'completed': False,
                'score': 0,
                'data': {},
                'feedback': ''
            },
            AssessmentStage.CULTURAL: {
                'completed': False,
                'score': 0,
                'data': {},
                'feedback': ''
            },
            AssessmentStage.SOFT_SKILLS: {
                'completed': False,
                'score': 0,
                'data': {},
                'feedback': ''
            },
            AssessmentStage.INTERVIEW: {
                'completed': False,
                'score': 0,
                'data': {},
                'feedback': ''
            },
            AssessmentStage.REFERENCES: {
                'completed': False,
                'score': 0,
                'data': {},
                'feedback': ''
            },
            AssessmentStage.BACKGROUND: {
                'completed': False,
                'score': 0,
                'data': {},
                'feedback': ''
            },
            AssessmentStage.PORTFOLIO: {
                'completed': False,
                'score': 0,
                'data': {},
                'feedback': ''
            }
        }
        self.current_stage = AssessmentStage.TECHNICAL
        self.overall_score = 0
        self.completed = False
        self.created_at = datetime.now().isoformat()
        self.updated_at = self.created_at

    def save(self):
        ref = db.reference(f'assessments/{self.application_id}')
        ref.set({
            'stages': self.stages,
            'current_stage': self.current_stage,
            'overall_score': self.overall_score,
            'completed': self.completed,
            'created_at': self.created_at,
            'updated_at': datetime.now().isoformat()
        })

    def complete_stage(self, stage_name, data, score):
        if stage_name in self.stages:
            self.stages[stage_name]['completed'] = True
            self.stages[stage_name]['data'] = data
            self.stages[stage_name]['score'] = score
            self.updated_at = datetime.now().isoformat()
            self.calculate_overall_score()
            self.check_completion()
            self.save()
            return True
        return False

    def calculate_overall_score(self):
        """Calculate weighted overall score based on stage importance"""
        weights = {
            AssessmentStage.TECHNICAL: 0.25,
            AssessmentStage.EXPERIENCE: 0.20,
            AssessmentStage.EDUCATION: 0.10,
            AssessmentStage.CULTURAL: 0.10,
            AssessmentStage.SOFT_SKILLS: 0.10,
            AssessmentStage.INTERVIEW: 0.10,
            AssessmentStage.REFERENCES: 0.05,
            AssessmentStage.BACKGROUND: 0.05,
            AssessmentStage.PORTFOLIO: 0.05
        }

        total_score = 0
        completed_weight = 0

        for stage, weight in weights.items():
            if self.stages[stage]['completed']:
                total_score += self.stages[stage]['score'] * weight
                completed_weight += weight

        self.overall_score = round(total_score / completed_weight * 100, 2) if completed_weight > 0 else 0

    def check_completion(self):
        """Check if all required stages are completed"""
        required_stages = [
            AssessmentStage.TECHNICAL,
            AssessmentStage.EXPERIENCE,
            AssessmentStage.EDUCATION,
            AssessmentStage.CULTURAL,
            AssessmentStage.SOFT_SKILLS
        ]

        self.completed = all(self.stages[stage]['completed'] for stage in required_stages)

    @staticmethod
    def get_by_id(application_id):
        ref = db.reference(f'assessments/{application_id}')
        data = ref.get()
        if data:
            assessment = Assessment(application_id)
            assessment.stages = data.get('stages', assessment.stages)
            assessment.current_stage = data.get('current_stage', assessment.current_stage)
            assessment.overall_score = data.get('overall_score', 0)
            assessment.completed = data.get('completed', False)
            assessment.created_at = data.get('created_at', assessment.created_at)
            assessment.updated_at = data.get('updated_at', assessment.updated_at)
            return assessment
        return None

class Application:
    def __init__(self, job_id, candidate_id, assessment_data=None):
        self.job_id = job_id
        self.candidate_id = candidate_id
        self.assessment_data = assessment_data or {}
        self.status = 'pending'
        self.match_score = 0
        self.created_at = datetime.now().isoformat()
        self.assessment = None #Added assessment attribute


    def save(self):
        ref = db.reference('applications').push()
        data = {
            'jobId': self.job_id,
            'candidateId': self.candidate_id,
            'assessmentData': self.assessment_data, #Added assessmentData
            'status': self.status,
            'matchScore': self.match_score,
            'createdAt': self.created_at
        }

        if self.assessment:
            data['assessmentId'] = self.assessment.application_id

        ref.set(data)
        return ref.key
        
    def calculate_match_score(self):
        """
        Calculate match score based on assessment data and job requirements
        Returns a score between 0-100
        """
        # Get job requirements
        job_ref = db.reference(f'jobs/{self.job_id}')
        job_data = job_ref.get()
        if not job_data:
            return 0

        score = 0
        weights = {
            'skills': 0.4,
            'experience': 0.3,
            'personality': 0.2,
            'cultural': 0.1
        }

        # Calculate skills match
        required_skills = set(job_data.get('requirements', []))
        candidate_skills = set(self.assessment_data.get('skills', []))
        skills_match = len(required_skills.intersection(candidate_skills)) / len(required_skills) if required_skills else 0

        # Calculate experience match
        exp_required = job_data.get('experienceRequired', 0)
        exp_candidate = self.assessment_data.get('experience', 0)
        exp_match = min(exp_candidate / exp_required, 1) if exp_required > 0 else 1

        # Calculate personality match (simplified)
        personality_score = sum(self.assessment_data.get('personality', {}).values()) / 5  # Assuming 5-point scale

        # Calculate cultural fit (simplified)
        cultural_score = sum(self.assessment_data.get('cultural', {}).values()) / 5

        # Calculate weighted score
        score = (
            weights['skills'] * skills_match +
            weights['experience'] * exp_match +
            weights['personality'] * personality_score +
            weights['cultural'] * cultural_score
        ) * 100

        self.match_score = round(score, 2)
        return self.match_score


class User:
    def __init__(self, uid, email, display_name, user_type='candidate'):
        self.uid = uid
        self.email = email
        self.display_name = display_name
        self.user_type = user_type
        self.profile = {}
        self.applications = []
        self.skills = []

    def save(self):
        ref = db.reference(f'users/{self.uid}')
        ref.set({
            'email': self.email,
            'displayName': self.display_name,
            'userType': self.user_type,
            'profile': self.profile,
            'applications': self.applications,
            'skills': self.skills,
            'createdAt': datetime.now().isoformat()
        })

    @staticmethod
    def get_by_id(uid):
        ref = db.reference(f'users/{uid}')
        data = ref.get()
        if data:
            user = User(uid, data['email'], data['displayName'], data['userType'])
            user.profile = data.get('profile', {})
            user.applications = data.get('applications', [])
            user.skills = data.get('skills', [])
            return user
        return None

class Job:
    def __init__(self, employer_id, title, company, description, requirements=None):
        self.employer_id = employer_id
        self.title = title
        self.company = company
        self.description = description
        self.requirements = requirements or []
        self.status = 'active'
        self.created_at = datetime.now().isoformat()

    def save(self):
        ref = db.reference('jobs').push()
        ref.set({
            'employerId': self.employer_id,
            'title': self.title,
            'company': self.company,
            'description': self.description,
            'requirements': self.requirements,
            'status': self.status,
            'createdAt': self.created_at
        })
        return ref.key

    @staticmethod
    def get_all_active():
        ref = db.reference('jobs')
        jobs = ref.order_by_child('status').equal_to('active').get()
        return jobs
