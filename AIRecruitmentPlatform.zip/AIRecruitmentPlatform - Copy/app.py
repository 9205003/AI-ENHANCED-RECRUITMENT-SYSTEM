import os
import json
import requests
from flask import (
    Flask,
    render_template,
    request,
    redirect,
    url_for,
    jsonify,
    session,
    flash,
)
import secrets
import string
import os
import cohere
import logging

logger = logging.getLogger(__name__)
import firebase_admin
from agora_service import create_agora_channel
from email_service import send_interview_invitation, send_code_snapshot
from mail import send_interview_notification
from firebase_admin import credentials, db, auth
from whereby import (generate_meeting_link,send_interview_notificationwhereby)
from corearch  import HolisticAssessmentEngine
from jobrecco import predict_resume_category_from_text

from flask_login import (
    LoginManager,
    UserMixin,
    login_user,
    logout_user,
    login_required,
    current_user,
)
import logging
from datetime import datetime

now = datetime.now()
combined_datetime = now.strftime("%A, %B %d, %Y | %I:%M:%S %p")

# Configure logging
logging.basicConfig(level=logging.DEBUG)

app = Flask(__name__)
app.secret_key = "muga1"
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = "index"
# Initialize Firebase Admin with credentials from environment variables
try:
    cred = credentials.Certificate(
        {
            "type": "service_account",
            # Firebase credentials omitted for security
            "project_id": "app-2f40e",
            "private_key_id": "b74939bb9d1414c4e139cc8003b7218be413a91f",
            "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQDgHT95qTqVI+Y6\ntO7mOh9Gay+l9h4ZroNsASw+vSoapdYVkMrL1/VvUicqL4LVnSfYN+fPkOg5YkqE\nGJ11TMpGXWBAF68DRwxv3069Fmiw7TDnQqdsbJvO4dLDPC6CYGnwn8MhDIiTPASp\ngCEH5s12QiB+7vVcyx4yaaxnaTNWHHw2S9I3a0ugyREfhs+5QfXWaIe5zEnHZTFn\njp6090ObVKXeM/CBjDymWz4VEOSr1KvOWfv4MxYdOk6TxL6vdxo0Z7wOB4rTKR2f\nNSv1SlWJPvBlWWooDfoL+6gocCtpiSSFKRQ4X9AgpgTCM8LEs2PP74HgL5ZtmdfB\n8XqZNLkjAgMBAAECggEAWZP3MhatHr2JoX9+WbFznL7s/aXhJBy31OynFbCgaqRM\nbLRCCrYYGNW6Z8czwVQef/Lgift+hqk95Yy9Kwx1cSiTdyrAPkwgsXqNS1DwqX80\n48qlhtXmdQuYJYchg+Urkw0YflY3JLqBloprKXBcQV9vA61Zjyx0tmu8iFzpMwpS\nEWOap3hSpEH6qXF7KWlFTTOtRbKx+ONxdAmT+HLiQJi4vUmEtPsZkk+tqm4YukBX\naE9zSwDcCWDKUnKXpSdob/bIQWiGqLkKgA8Cs/mhBEd+0CTWKPtuYgEuEJxRmeRt\nmUypqT+8QEiwN+wVlRnfJ3D+PR0gDhI3FUAiX3YZ6QKBgQD4zBE4fxCoJaxHmJtK\nCtxSbLcy6c5YflDK2CEH+gr9ZpFBw4EMyaJyc37MWroFE3m0auL42hHABxOwASeP\nCmC60UhRoq2iT6DfjJtijHd/LWxCdyt5TbUsedTDGsdX/yi8gWQwzC+5XrtAo68a\n7umJ3Zgp4n3+SYi+BEX1d8/AtwKBgQDmmj8EcuOJIyuTB4oIMuSosgMWHa090h7T\nLk4cPyawhTQyIrXDRwTic22NRsmTbo5f+yaa4D87JnQkAkyPI1AnWxPXrZMAKWPq\nIfLq5DPhw7aU4FWxn9I8qhwG0hSUTOQ/Q7raHqVoO84CaktBMuFaQt47WH/jTVC9\naYOIfwsG9QKBgADS5Ce0vABih4yBI9p96LbZJ04i2g0O9gOF7a4SFOE76rU2CYJa\nVJBec4gHsN/9bYS8ad37Et346AbIKjJeDW3w7XVfvYVxEA5Nb+JGpsqkAtzBekJf\nkH8CNEMlHo3bCW5+Wy+SLYJGnwYaxKSpL9rGAg/5cQNbiPlgGD8001pHAoGBAINZ\nHkXZbtMBDmPL6opq+qU/59QkCTZqRZaCDIm4SsBGzwkzjhZxkE2v85mB1XU9hqkS\n89VJn5qAd6y/Bn6NXa1dCjtSKaXw7XFB7wxt+UNB5/B6qzTmVKirOBWGeaRS+7sx\nR+/PfuWVEu17P+weIA/6gHyLFyUQN8n7nKkVu+E1AoGBAMrjVekaMv+qQZ4DUqRh\nc5HRBhhuhZBJjlpCExP0LVc7MSlZCX67DNCl9TXHwjGj2SKoaalFcxzpbBwJOCNQ\nOCEGQ/TSOIedrmN5tz+p/oR2hi2vFnh7wiYjkU+/IzPKLcHMJBORqZTdxtdb6Mpp\nH5sZGtmOFh8p1c9IrO7fc6qd\n-----END PRIVATE KEY-----\n",
            "client_email": "firebase-adminsdk-fbsvc@app-2f40e.iam.gserviceaccount.com",
            "client_id": "111202711932862870666",
            "auth_uri": "https://accounts.google.com/o/oauth2/auth",
            "token_uri": "https://oauth2.googleapis.com/token",
            "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
            "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-fbsvc%40app-2f40e.iam.gserviceaccount.com",
            "universe_domain": "googleapis.com",
        }
    )

    firebase_admin.initialize_app(
        cred, {"databaseURL": "https://app-2f40e-default-rtdb.firebaseio.com"}
    )
    logging.info("Firebase Admin SDK initialized successfully")
except Exception as e:
    logging.error(f"Error initializing Firebase Admin SDK: {e}")
    raise


class User(UserMixin):
    def __init__(self, uid, email=None, display_name=None, user_type=None):
        self.id = uid
        self.email = email
        self.display_name = display_name
        self.user_type = user_type  # Store whether employer or candidate


@login_manager.user_loader
def load_user(user_id):
    try:
        # First check if user exists in Firebase Auth
        try:
            user = auth.get_user(user_id)
        except auth.UserNotFoundError:
            logging.warning(f"User {user_id} not found in Firebase Auth")
            return None
        except Exception as e:
            logging.error(f"Firebase Auth error: {e}")
            # Important: Return a basic user object instead of None
            # This prevents session loss during registration
            return User(user_id, None, None, None)

        # If we get here, user exists in Firebase Auth
        # Even if they don't exist in the database yet, we should return a User object
        # to maintain their session during the registration process

        # Try to get user type from database
        user_type = None

        # Check if user is an employer
        employer_ref = db.reference(f"employers/{user_id}")
        employer_data = employer_ref.get()
        if employer_data:
            user_type = "employer"
        else:
            # Check if user is a candidate
            user_ref = db.reference(f"users/{user_id}")
            user_data = user_ref.get()
            if user_data:
                user_type = "candidate"

        # Return a user object regardless of whether they exist in the database
        return User(user_id, user.email, user.display_name, user_type)

    except Exception as e:
        logging.error(f"Error loading user: {e}")
        # This is critical - we should return a User object to maintain the session
        # during registration rather than returning None
        return User(user_id, None, None, None)


# Error handler for API routes
@app.errorhandler(404)
def not_found_error(error):
    if request.path.startswith("/api/"):
        return jsonify({"error": "Not found"}), 404
    return render_template("404.html", firebase_config=get_firebase_config()), 404


@app.errorhandler(500)
def internal_error(error):
    if request.path.startswith("/api/"):
        return jsonify({"error": "Internal server error"}), 500
    return render_template("500.html", firebase_config=get_firebase_config()), 500


def get_firebase_config():
    return {
        "apiKey": "AIzaSyDS3i6Xt4WxkQC856pLdaEcrCb_migYOmg",
        "authDomain": "app-2f40e.firebaseapp.com",
        "databaseURL": "https://app-2f40e-default-rtdb.firebaseio.com",
        "projectId": "app-2f40e",
        "storageBucket": "app-2f40e.firebasestorage.app",
        "messagingSenderId": "854016940744",
        "appId": "1:854016940744:web:86ddd346e7e958e2e563fd",
    }


def flash_message(message, message_type):
    """
    Flash a message to the user interface with a specific type.

    Parameters:
        message (str): The content of the message to display.
        message_type (str): The type of the message. Supported types:
            - 'error': For error messages.
            - 'success': For success messages.
            - 'warning': For warning messages.
            - 'recommendation': For recommendation or informational messages.

    Returns:
        None
    """
    # Validate the message type
    valid_types = ["error", "success", "warning", "recommendation"]
    if message_type not in valid_types:
        raise ValueError(
            f"Invalid message type: {message_type}. Must be one of {valid_types}"
        )

    # Flash the message with its type as a category
    flash(message, message_type)

    ###################cohere stuff#########


def get_cohere_client():
    """Initialize and return a Cohere client instance"""
    api_key = "gQExRnMZ9jw42H66ISJLfvBMQk7rP7k5fbBI0P7a"

    if not api_key:
        logger.warning("COHERE_API_KEY not found in environment variables")
        return None

    return cohere.Client(api_key)


def get_cohere_response(user_message, model="command", max_tokens=500):
    """
    Get a response from the Cohere API based on user message

    Args:
        user_message (str): The user's message
        model (str): Cohere model to use
        max_tokens (int): Maximum number of tokens in response

    Returns:
        str: The AI-generated response
    """
    try:
        client = get_cohere_client()

        if not client:
            return "I'm sorry, but I can't access my AI capabilities at the moment. Please try again later."

        # Prepare a friendly system prompt that defines the assistant's behavior
        system_prompt = """
        You are a helpful, friendly assistant integrated into a website. Your goal is to provide 
        accurate, concise, and helpful responses to user queries. Be conversational but professional.
        Avoid generating harmful, offensive, or misleading content. If you don't know the answer to 
        a question, admit it rather than making something up.
        """

        # Get generation from Cohere
        response = client.chat(
            message=user_message,
            model=model,
            max_tokens=max_tokens,
            temperature=0.1,
            preamble=system_prompt,
        )

        # Extract the text from the response
        return response.text

    except Exception as e:
        logger.error(f"Error getting response from Cohere: {str(e)}")
        return "I apologize, but I'm having trouble connecting to my AI services. Please try again later."


def extract_resume_data(resume_text):
    """
    Extracts structured data from a resume text using the Talent Track API.

    Parameters:
        resume_text (str): The raw text content of the resume.

    Returns:
        dict: The parsed JSON response from the API, or None if an error occurs.
    """
    # Define the API endpoint URL
    url = "https://talent-track.p.rapidapi.com/functions/v1/v1-rapid-extract-resume"

    # Hardcoded API key and host (replace these with your actual credentials)
    API_KEY = "90a7af4e77msh080b5db65552bd5p18151ajsn7530ad125db0"
    API_HOST = "talent-track.p.rapidapi.com"

    # Prepare the payload and headers
    payload = {"resumeText": resume_text}
    headers = {
        "x-rapidapi-key": API_KEY,
        "x-rapidapi-host": API_HOST,
        "Content-Type": "application/json",
    }

    try:
        # Make the POST request to the API
        response = requests.post(url, json=payload, headers=headers)

        # Raise an exception if the request was unsuccessful
        response.raise_for_status()

        # Parse and return the JSON response
        return response.json()

    except requests.exceptions.RequestException as e:
        # Handle any errors that occur during the request
        print(f"An error232 occurred while making the API request: {e}")
        return None


@app.route("/api/check_user/<uid>")
def check_user(uid):
    try:
        # Check if user exists in our database
        user_ref = db.reference(f"users/{uid}")
        employer_ref = db.reference(f"employers/{uid}")

        user_data = user_ref.get()
        employer_data = employer_ref.get()

        # Return user type along with existence status
        user_type = None
        if employer_data:
            user_type = "employer"
        elif user_data:
            user_type = "candidate"

        return jsonify(
            {"exists": bool(user_data or employer_data), "user_type": user_type}
        )
    except Exception as e:
        logging.error(f"Error checking user: {e}")
        return jsonify({"error": str(e)}), 500


@app.route("/api/user_login", methods=["POST"])
def user_login():
    try:
        if not request.is_json:
            return (
                jsonify(
                    {
                        "status": "error",
                        "message": "Content-Type must be application/json",
                    }
                ),
                400,
            )

        data = request.get_json()
        if not data or "uid" not in data:
            return (
                jsonify({"status": "error", "message": "Missing uid in request"}),
                400,
            )

        # Get the user type from request
        user_type = data.get("userType", "candidate")
        uid = data["uid"]

        # Verify the user with Firebase
        try:
            user = auth.get_user(uid)
        except Exception as e:
            logging.error(f"Firebase Auth error: {e}")
            return jsonify({"status": "error", "message": str(e)}), 401

        # Create a Flask-Login user and log them in before database operations
        flask_user = User(uid, user.email, user.display_name, user_type)
        login_user(flask_user)

        # Now store/update user data in database
        try:
            if user_type == "employer":
                # Store in employers collection
                user_ref = db.reference(f"employers/{uid}")
                user_data = user_ref.get()
                if not user_data:
                    # Create new employer record
                    user_ref.set(
                        {
                            "email": user.email,
                            "displayName": user.display_name or "",
                            "userType": "employer",
                            "createdAt": {".sv": "timestamp"},
                            "company": "",
                            "position": "",
                            "verified": False,
                            "jobs": {},
                            "applications": {},
                        }
                    )
                else:
                    # Update existing employer data if needed
                    updates = {
                        "email": user.email,
                        "displayName": user.display_name or "",
                    }
                    user_ref.update(updates)
            else:
                # Store in users collection (candidates)
                user_ref = db.reference(f"users/{uid}")
                user_data = user_ref.get()
                if not user_data:
                    # Create new candidate record
                    user_ref.set(
                        {
                            "email": user.email,
                            "displayName": user.display_name or "",
                            "userType": "candidate",
                            "createdAt": {".sv": "timestamp"},
                            "resume": "",
                            "skills": [],
                            "applications": {},
                        }
                    )
                else:
                    # Update existing candidate data if needed
                    updates = {
                        "email": user.email,
                        "displayName": user.display_name or "",
                    }
                    user_ref.update(updates)

        except Exception as e:
            logging.error(f"Database error: {e}")
            # Continue anyway - the user is logged in, we can fix the database later

        return jsonify(
            {
                "status": "success",
                "user": {
                    "uid": uid,
                    "email": user.email,
                    "displayName": user.display_name or "",
                    "userType": user_type,
                },
            }
        )

    except Exception as e:
        logging.error(f"Login error: {e}")
        return jsonify({"status": "error", "message": str(e)}), 401


@app.route("/api/user_type/<uid>")
def get_user_type(uid):
    try:
        # Check if user is in employers collection
        employer_ref = db.reference(f"employers/{uid}")
        employer_data = employer_ref.get()

        if employer_data:
            return jsonify({"type": "employer"})

        # If not an employer, check the users collection
        user_ref = db.reference(f"users/{uid}")
        user_data = user_ref.get()

        if user_data:
            return jsonify({"type": "candidate"})

        # User not found in either collection
        return jsonify({"type": None, "error": "User not found in database"}), 404
    except Exception as e:
        logging.error(f"Error getting user type: {e}")
        return jsonify({"error": str(e)}), 500


@app.route("/api/user_logout")
@login_required
def user_logout():
    try:
        logout_user()
        return jsonify({"status": "success"})
    except Exception as e:
        logging.error(f"Logout error: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500


# Regular routes
@app.route("/")
def index():
    return render_template("index.html", firebase_config=get_firebase_config())


@app.route("/faqs")
def faqs():
    return render_template("faqs.html", firebase_config=get_firebase_config())


@app.route("/jobs")
def jobs():
    try:
        # Fetch jobs data
        jobs_ref = db.reference("jobs")
        jobs_data = jobs_ref.get() or {}
        
        for job_id, job_info in jobs_data.items():
            job_skills = job_info.get('skills', [])
            job_skills = [skill.lower() for skill in job_skills]
            print(f"Job skills for {job_id}: {job_skills}")
            
        userref= db.reference(f"users/{current_user.id}")
        
        userdata=userref.get() or {}
        profile=userdata['profile']
        user_skills = profile.get('skills', [])
        normalized_user_skills = [skill['skillName'].lower() for skill in user_skills]
        print(normalized_user_skills)
        
        
        
          
           
          
           
       
        
        # Render the template
        return render_template(
            "jobs.html", jobs=jobs_data, firebase_config=get_firebase_config()
        )
            
    except Exception as e:
        logging.error(f"Error fetching jobs or user data: {e}", exc_info=True)
        return render_template(
            "jobs.html", jobs={}, firebase_config=get_firebase_config()
        )
        
@app.route("/candidate_profile", methods=["GET", "POST"])
def candidate_profile():
    if request.method == "POST":
        try:
            # Extract form data
            name = request.form.get("name")
            headline = request.form.get("headline")
            skills = request.form.get("skills")
            experience = request.form.get("experience")
            bio = request.form.get("bio")

            # Validate input (basic validation)
            if not name or not skills or not experience:
                flash("All fields are required!", "danger")
                return render_template("404.html"), 404  # Redirect to custom 404 page

            # Save profile data to Firebase
            user_id = (
                current_user.id
            )  # Replace with actual user ID from session or authentication
            profiles_ref = db.reference(f"users/{user_id}/profile")
            profiles_ref.set(
                {
                    "name": name,
                    "headline": headline,
                    "skills": skills,
                    "experience": experience,
                    "bio": bio,
                }
            )

            # Flash success message
            flash("Profile created successfully!", "success")

            # Redirect to a dashboard or profile page
            return redirect(
                url_for("profile")
            )  # Replace with your actual dashboard route

        except Exception as e:
            # Log the error (optional)
            print(f"Error: {str(e)}")
            flash_message(
                "An internal error occurred. Please try again later.", "danger"
            )
            return render_template("500.html"), 500  # Redirect to custom 500 page

    # Render the profile creation form for GET requests
    return render_template(
        "candidateprofile.html", firebase_config=get_firebase_config()
    )  # Replace with your actual template name


@app.route("/employer_profile", methods=["GET", "POST"])
def employer_profile():
    if request.method == "POST":
        try:
            # Extract form data
            companyname = request.form.get("companyName")
            company_website = request.form.get("website")
            company_size = request.form.get("size")
            recruiter_position = request.form.get("position")
            company_industry = request.form.get("industry")
            company_description = request.form.get("description")

            # Validate input (basic validation)
            if not companyname or not recruiter_position or not company_description:
                flash_message("All fields are required!", "danger")
                return (
                    render_template("500.html", firebase_config=get_firebase_config()),
                    404,
                )  # Redirect to custom 404 page

            # Save profile data to Firebase
            user_id = (
                current_user.id
            )  # Replace with actual user ID from session or authentication
            profiles_ref = db.reference(f"employers/{user_id}/profile")
            profiles_ref.set(
                {
                    "name": companyname,
                    "website": company_website,
                    "size": company_size,
                    "recruiter_position": recruiter_position,
                    "industry": company_industry,
                    "description": company_description,
                }
            )

            # Flash success message
            flash_message("Profile created successfully!", "success")

            # Redirect to a dashboard or profile page
            return redirect(
                url_for("profile")
            )  # Replace with your actual dashboard route

        except Exception as e:
            # Log the error (optional)
            print(f"Error: {str(e)}")
            flash_message(
                "An internal error occurred. Please try again later.", "danger"
            )
            return (
                render_template("500.html", firebase_config=get_firebase_config()),
                500,
            )  # Redirect to custom 500 page

    # Render the profile creation form for GET requests
    return render_template(
        "employerprofile.html", firebase_config=get_firebase_config()
    )  # Replace with your actual template name


@app.route("/profile")
@login_required
def profile():
    try:
        # Check user type and redirect if necessary
        if current_user.user_type == "employer":
            flash("You have been redirected to the employer dashboard.", "info")
            return redirect(url_for("employer_dashboard"))

        # Fetch user data from Firebase
        user_ref = db.reference(f"users/{current_user.id}")
        user_data = user_ref.get() or {}

        if not user_data:
            flash(
                "Your profile data could not be found. Please update your profile.",
                "warning",
            )

        return render_template(
            "profile.html", user=user_data, firebase_config=get_firebase_config()
        )

    except Exception as e:
        logging.error(f"Error fetching user profile: {e}")
        flash(
            "An error occurred while loading your profile. Please try again later.",
            "danger",
        )
        return redirect(url_for("index"))


@app.route("/add_job", methods=["GET", "POST"])
@login_required  # Ensures user is logged in
def add_job():
    if request.method == "POST":

        # Extract form data
        jobTitle = request.form.get("title", "").strip()
        company = request.form.get("company", "").strip()
        location = request.form.get("location", "").strip()
        jobType = request.form.get("job_type", "").strip()
        job_industry = request.form.get("industry", "").strip()
        skills_raw = request.form.get("skills", "").strip()
        experience = request.form.get("experience", "").strip()
        salary = request.form.get("salary", "").strip()
        description = request.form.get("description", "").strip()
        skills = (
            [skill.strip() for skill in skills_raw.split(",")] if skills_raw else []
        )

        # Current user ID and timestamp
        job_posted_by = current_user.id
        job_posted_on = combined_datetime

        # Comprehensive validation

        # Create job data dictionary
        job_data = {
            "jobTitle": jobTitle,
            "company": company,
            "location": location,
            "jobType": jobType,
            "job_industry": job_industry,
            "skills": skills,
            "experience": experience,
            "salary": salary,
            "description": description,
            "job_posted_by": job_posted_by,
            "job_posted_on": job_posted_on,
        }
        print(job_data)
        user_id = current_user.id

        all_jobs_ref = db.reference("jobs").push(job_data)
        job_id = all_jobs_ref.key
        job_data["job_id"] = job_id

        employer_ref = db.reference(f"employers/{user_id}/jobs/{job_id}")
        employer_ref.set(job_data)
        all_jobs_ref.update({"job_id": job_id})

        flash_message("Job created successfully!", "success")
        return redirect(url_for("employer_dashboard"))

    return render_template(
        "addjob.html",
        firebase_config=get_firebase_config(),
    )


# New API endpoint for updating candidate profile


# New API endpoint for updating employer profile


@app.route("/employer/dashboard")
@login_required
def employer_dashboard():
    try:
        # Check if user is an employer
        if current_user.user_type != "employer":
            flash("Access denied. You must be an employer to view this page.")
            return redirect(url_for("index"))

        employer_ref = db.reference(f"employers/{current_user.id}")
        employer_data = employer_ref.get() or {}

        # Get the jobs created by this employer
        jobs_ref = db.reference("jobs")
        all_jobs = jobs_ref.get() or {}
        employer_jobs = {}

        for job_id, job in all_jobs.items():
            if job.get("employerId") == current_user.id:
                employer_jobs[job_id] = job

        return render_template(
            "employer_dashboard.html",
            employer=employer_data,
            jobs=employer_jobs,
            firebase_config=get_firebase_config(),
        )
    except Exception as e:
        logging.error(f"Error fetching employer dashboard: {e}")
        return redirect(url_for("index"))


##############################################################################################
@app.route("/assessment/profile")
@login_required
def profile_assessment():
    try:
        # Check if user is a candidate
        if current_user.user_type != "candidate":
            flash_message("Only candidates can update their profile")
            return redirect(url_for("profile"))

        # If user already has a profile, we could pre-fill the form
        # Leaving this part simple for now
        return render_template(
            "assessment.html",
            profile_assessment=True,
            firebase_config=get_firebase_config(),
        )

    except Exception as e:
        logging.error(f"Error loading profile assessment: {e}")
        return redirect(url_for("profile"))


##############################################################################################
import json  # Import the json module for parsing JSON strings


@app.route("/api/submit_assessment", methods=["POST"])
@login_required
def submit_assessment():
    try:
        # Ensure the request content type is JSON
        if not request.is_json:
            return (
                jsonify(
                    {
                        "status": "error",
                        "message": "Content-Type must be application/json",
                    }
                ),
                400,
            )

        # Verify user is a candidate
        if current_user.user_type != "candidate":
            return (
                jsonify(
                    {
                        "status": "error",
                        "message": "Only candidates can submit profile data",
                    }
                ),
                403,
            )

        # Parse the incoming JSON data
        data = request.get_json()

        # Add metadata: current user ID and timestamp
        data["user_id"] = current_user.id
        data["timestamp"] = {".sv": "timestamp"}

        # Extract resume-related fields
        resume = data.get("resume", {})
        
        resume_raw_text = resume.get("rawText", "No resume content extracted"),
        resume_prepared_text = resume.get("preparedText", "No prepared text available"),
        recommendation = predict_resume_category_from_text(resume_raw_text),
        resume_analysis_report = resume.get(
            "analysisReport", {"error": "No analysis report generated"}
        )

        # Perform resume data extraction
        

        # Check if `result` is a JSON string and parse it into a dictionary
        if isinstance(result, str):
            try:
                result = json.loads(result)  # Parse JSON string into a dictionary
            except json.JSONDecodeError:
                logging.error("Failed to parse result as JSON")
                return (
                    jsonify(
                        {
                            "status": "error",
                            "message": "Invalid JSON in resume extraction result",
                        }
                    ),
                    500,
                )

        # Validate that `result` is a dictionary and contains data
        if not isinstance(result, dict) or not result:
            logging.error("Resume extraction returned invalid or empty result")
            return (
                jsonify(
                    {"status": "error", "message": "Failed to extract resume data"}
                ),
                500,
            )

        # Add all contents of `result` to `data`
        data.update(result)  # Merge `result` into `data`

        # Save the assessment directly to the user's profile in the database
        userprofile = db.reference(f"users/{current_user.id}/profile").set(data)

        # Return success response
        return jsonify({"status": "success", "message": "Profile updated successfully"})

    except Exception as e:
        # Log the error and return an error response
        logging.error(f"Error submitting profile assessment: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500


##############################################################################################
def get_job_by_id(job_id):
    # Get data from Firebase Realtime Database
    job_data = db.reference(f"jobs/{job_id}").get()

    if job_data:
        job_data["jobId"] = job_id  # Add the ID to the data
        return job_data

    return None


##############################################################################################
def get_user_details(user_id):

    # Fetch user data from Firebase Realtime Database
    user_details = db.reference(f"users/{user_id}").get()

    if user_details:
        # Add the user ID to the data for convenience
        user_details["id"] = user_id
        return user_details

    # Return None if no user details are found
    return None


##############################################################################################
@app.route("/submitjob/<job_id>")
@login_required
def submit_job(job_id):
    try:
        # Check if user is a candidate
        if current_user.user_type != "candidate":
            flash_message("Only candidates can submit job applications","error")
            return redirect(url_for("profile"))

        # Get job details from your database using job_id
        # This is the missing part - you need to fetch the job data
        job = get_job_by_id(job_id)
        # Create this function based on your database setup

        user_ref = db.reference(f"users/{current_user.id}")
        user_data = user_ref.get() or {}

        if not user_ref:
            flash_message("User details not found")
            return redirect(url_for("profile"))

        if not job:
            flash_message("Job not found")
            return redirect(url_for("jobs"))

        return render_template(
            "submitjob.html",
            user=user_data,
            job=job,  # Pass the job object to the template
            firebase_config=get_firebase_config(),
        )

    except Exception as e:
        logging.error(f"Error submitting job application: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500


@app.route("/process_job_application", methods=["POST"])
def process_job_application():
    try:
        job_id = request.form.get("jobId")
        cover_letter = request.form.get("coverLetterText")
        why_job = request.form.get("whyJob")
        salary_expectations = request.form.get("salaryExpectations")
        availability_date = request.form.get("availabilityDate")
        work_eligibility = request.form.get("workEligibility")
        emp_id = request.form.get("empid")
        job_title = request.form.get("jobtitle")
        company = request.form.get("company")

        # Parse CV analysis result
        cv_analysis_result = json.loads(request.form.get("cvAnalysisResult", "{}"))

        if (
            not job_id
            or not cover_letter
            or not why_job
            or not salary_expectations
            or not availability_date
            or not work_eligibility
            or not cv_analysis_result
            or not emp_id
            or not job_title
            or not company
        ):
            flash("All fields are required.", "error")

        #####get current user profile
        profile_ref = db.reference(f"users/{current_user.id}/profile")
        profile = profile_ref.get()
        print(profile)

        assessment_data = {
            "Job ID": job_id,
            "Cover Letter": cover_letter,
            "Why this job": why_job,
            "Salary expectations": salary_expectations,
            "Available from": availability_date,
            "Work eligibility": work_eligibility,
            "analysis": cv_analysis_result,
            "empid": emp_id,
            "jobTitle": job_title,
            "profile": profile,
            "company": company,
            "dateApplied": combined_datetime,
        }
        assessment_ref = db.reference("assessments")
        new_assessment = assessment_ref.push(assessment_data)
        assessment_id = new_assessment.key

        # Update the user's applications list
        user_app_ref = db.reference(
            f"users/{current_user.id}/applications/{assessment_id}"
        )
        user_app_ref.set(assessment_data)

        # Update the employer's applications list
        employer_app_ref = db.reference(
            f"employers/{emp_id}/applications/{assessment_id}"
        )
        employer_app_ref.set(assessment_data)

        # Update the job's applications list
        job_app_ref = db.reference(f"jobs/{job_id}/applications/{current_user.id}")
        job_app_ref.set(assessment_data)

        app.logger.info(f"Application successfully saved with ID: {assessment_id}")

        # ...
        # If all is successful
        return jsonify({"status": "success"}), 200
    except Exception as e:
        # Log the error to the console or a log file
        print(f"Error processing job application: {e}")
        # Return a detailed error message in the JSON response
        return jsonify({"status": "error", "message": str(e)}), 500

    ##########################assistant routes


@app.route("/assistant")
def assistant_view():
    """Render the assistant chat interface"""
    return render_template("assistant.html", firebase_config=get_firebase_config())


@app.route("/api/chat", methods=["POST"])
def chat_endpoint():
    """Process incoming chat messages"""
    try:
        data = request.json
        user_message = data.get("message", "").strip()

        if not user_message:
            return jsonify({"error": "Empty message"}), 400

        # Use Cohere for AI-generated response
        response = get_cohere_response(user_message)
        source = "Cohere"

        # Format response for better display
        # Break any extremely long words that might cause overflow
        words = response.split()
        formatted_words = []
        for word in words:
            if len(word) > 30:  # Break very long words
                chunks = [word[i : i + 30] for i in range(0, len(word), 30)]
                formatted_words.extend(chunks)
            else:
                formatted_words.append(word)

        formatted_response = " ".join(formatted_words)

        # Enforce maximum length
        if len(formatted_response) > 2000:
            formatted_response = formatted_response[:1997] + "..."

        logger.debug(f"Sending response of length: {len(formatted_response)}")

        return jsonify({"response": formatted_response, "source": source})

    except Exception as e:
        logger.error(f"Error in chat endpoint: {str(e)}")
        return jsonify({"error": "Failed to process your request"}), 500


@app.route("/create-interview", methods=["GET", "POST"])
@login_required
def create_interview():
    if request.method == "POST":
        title = request.form.get("title")
        description = request.form.get("description")
        participant_email = request.form.get("participant_email")
        scheduled_date = request.form.get("scheduled_date")
        scheduled_time = request.form.get("scheduled_time")
        duration = request.form.get("duration", 60)
        language = request.form.get("language", "javascript")
        position_type = request.form.get("position_type", "")
        skill_level = request.form.get("skill_level", "")
        participant_id=request.form.get("user_id")

        # Validation
        if not all([title, participant_email, scheduled_date, scheduled_time]):
            flash_message(
                "Title, participant email, and scheduled time are required", "danger"
            )
            return render_template("404.html")

        # Parse date and time
        try:
            scheduled_datetime = datetime.strptime(
                f"{scheduled_date} {scheduled_time}", "%Y-%m-%d %H:%M"
            )
        except ValueError:
            flash_message("Invalid date or time format", "warning")
            return render_template("404.html")

        # Check if participant exists

        creator_id = db.reference(f"employers/{current_user.id}/applications")

        userref = db.reference(f"users/{participant_id}")
        
      

        # Generate room code
        room_code = "".join(
            secrets.choice(string.ascii_uppercase + string.digits) for _ in range(8)
        )
        room_id=room_code
        meetinglink = generate_meeting_link(room_id)
        participant_meeting_link = meetinglink.split('?')[0] if '?' in meetinglink else meetinglink
        
        # Try to create an Agora video channel
        agora_data = None
        try:
            agora_data = create_agora_channel(title, scheduled_datetime, int(duration))
            if not agora_data:
                flash_message(
                    "Unable to create video call. The interview will still be scheduled, but video may not be available.",
                    "warning",
                )
        except Exception as e:
            logger.error(f"Error creating Agora channel: {str(e)}")
            flash_message(
                "Unable to create video call. The interview will still be scheduled, but video may not be available.",
                "warning",
            )

        # Store the Agora data as a JSON string in the agora_channel field
        agora_channel_data = json.dumps(agora_data) if agora_data else None
        

        interview = {
        "title": title,
        "description": description,
        "creator_id": current_user.id,
        "participant_id": participant_id,
        "participant_email": participant_email,
        "scheduled_time": scheduled_datetime.isoformat(),  # Store datetime as ISO string
        "duration": duration,
        "agora_channel_data": agora_channel_data,
        "room_code": room_code,
        "language": language,
        "position_type": position_type,
        "skill_level": skill_level,
        "room_id": room_id,
        "meeting_link":meetinglink,
        "participant_meeting_link":participant_meeting_link
        
        }
        
        

        try:
            ###########
            
           # Store interview data using room_code as the key
            interviews_ref = db.reference("interviews")
            interviews_ref.child(room_code).set(interview)
                    # Store participant-specific data
            usersref = db.reference(f"users/{participant_id}")
            participant_data = {
                "participant_meeting_link": interview["participant_meeting_link"],
                "scheduled_time": interview["scheduled_time"]
            }
            usersref.child("interviews").child(room_code).set(participant_data)

            # Store employer-specific data
            employersref = db.reference(f"employers/{current_user.id}")
            employersref.child("interviews").child(room_code).set(interview)

            # Send invitation email to participant
            email_sent = send_interview_notification(participant_email, interview)
            email_sentwhereby = send_interview_notificationwhereby(interview)
            if email_sent:
                flash_message(
                    "Interview scheduled successfully and invitation sent!", "success"
                )
            else:
                flash_message(
                    "Interview scheduled successfully, but there was an issue sending the invitation email.",
                    "warning",
                )

            return redirect(url_for("dashboard"))
        except Exception as e:
            logger.error(f"Error creating interview: {str(e)}")
            flash_message("An error occurred while scheduling the interview", "warning")

    return render_template("createinterview.html", firebase_config=get_firebase_config())


@app.route("/interview/<room_code>", methods=["GET"])
@login_required
def get_interview_details(room_code):
    # Reference to the interviews table in the database
    interviews_ref = db.reference("interviews")
    
    # Retrieve the interview data using the room_code as the key
    interview_data = interviews_ref.child(room_code).get()
    
    if not interview_data:
        return jsonify({"error": "Interview not found"}), 404
    
    # Get the current user's ID from Flask-Login's current_user
    current_user_id = current_user.id
    
    # Determine if the current user is the host or participant
    is_host = current_user_id == interview_data.get("creator_id")
    is_participant = current_user_id == interview_data.get("participant_id")
    
    if not is_host and not is_participant:
        return jsonify({"error": "You are not authorized to access this interview"}), 403
    
    # Select the appropriate meeting link based on the role
    meeting_link = interview_data.get("meeting_link") if is_host else interview_data.get("participant_meeting_link")
    display_name = "Host" if is_host else interview_data.get("participant_email", "Participant")
    
    # Prepare the interview data for the template
    interview_details = {
        "room_code": room_code,
        "title": interview_data.get("title"),
        "description": interview_data.get("description"),
        "creator_id": interview_data.get("creator_id"),
        "participant_id": interview_data.get("participant_id"),
        "participant_email": interview_data.get("participant_email"),
        "scheduled_time": interview_data.get("scheduled_time"),
        "duration": interview_data.get("duration"),
        "language": interview_data.get("language"),
        "position_type": interview_data.get("position_type"),
        "skill_level": interview_data.get("skill_level"),
        "meeting_link": meeting_link,
        "whereby_embed": {
            "room": meeting_link,
            "display_name": display_name,
            "audio": "on",
            "video": "on",
            "background": "on",
            "screenshare": "on",
            "chat": "on"
        }
    }
    
    return render_template("interviewroom.html", interview_data=interview_details, firebase_config=get_firebase_config())
    
@app.route('/invites')
@login_required 
def invites ( invites):
    user_id=current_user.id
    
    interview_data=db.refrence .child("interviews").child({user_id})
    
    return jsonify({
        "interviews":interview_data.get()
    })
    

     
    return render_template("invites.html",firebase_config=get_firebase_config)
        
@app.route('/cohere test')
def cohere():
    return render_template("cohere.html", firebase_config=get_firebase_config())

@app.route('/406')
def error():
    
    user_id= current_user.id
    return render_template("406.html",user_id=user_id, firebase_config=get_firebase_config())

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
