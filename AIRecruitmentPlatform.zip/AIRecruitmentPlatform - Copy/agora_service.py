"""
Agora Video Service Module for TechInterview Platform
This module handles token generation and video conferencing integration with Agora.io
"""
import os
import logging
import random
import string
import time
from datetime import datetime, timedelta

# Configure logger
logger = logging.getLogger(__name__)

# Import Agora token builder
try:
    from agora_token_builder import RtcTokenBuilder
except ImportError:
    # Fallback implementation for token generation if the package is not available
    logger.error("Failed to import agora_token_builder. Using fallback implementation.")
    
    class RtcTokenBuilder:
        @staticmethod
        def buildTokenWithUid(appId, appCertificate, channelName, uid, role, privilegeExpiredTs):
            """
            Simplified token generation as a fallback
            In production, always use the proper agora_token_builder package
            """
            import hmac
            import base64
            import struct
            import time
            import zlib
            
            # This is a simplified implementation and should not be used in production
            # It's only here as a fallback if the agora_token_builder package is not available
            
            # Use a simplified token format as fallback
            token_items = {
                "appId": appId,
                "channelName": channelName,
                "uid": str(uid),
                "role": role,
                "expire": privilegeExpiredTs
            }
            
            # Create a signature using HMAC-SHA256
            message = f"{appId}{channelName}{uid}{role}{privilegeExpiredTs}"
            signature = hmac.new(
                appCertificate.encode(),
                message.encode(),
                digestmod='sha256'
            ).digest()
            
            # Encode the token
            token_content = f"{appId}.{channelName}.{uid}.{role}.{privilegeExpiredTs}.{signature.hex()}"
            compressed = zlib.compress(token_content.encode())
            b64encoded = base64.b64encode(compressed).decode('utf-8')
            
            return b64encoded

# Get Agora credentials from environment variables
AGORA_APP_ID = '01192e1c8aa545aebea3a7ff2ad50cb4'
AGORA_APP_CERTIFICATE = "301e0807c39b436abbfbd2a6aa4d24a4"

# Role constants for token generation
PUBLISHER_ROLE = 1  # Host/broadcaster role
AUDIENCE_ROLE = 2   # Audience/viewer role


def generate_channel_name(title, scheduled_time):
    """
    Generate a unique channel name for the interview
    
    Args:
        title (str): Title of the interview
        scheduled_time (datetime): Scheduled start time
    
    Returns:
        str: A unique channel name
    """
    # Create a clean channel name from title by removing special characters
    clean_title = ''.join(c for c in title if c.isalnum()).lower()
    
    # Add timestamp and random string for uniqueness
    timestamp = int(scheduled_time.timestamp())
    random_suffix = ''.join(random.choice(string.ascii_lowercase + string.digits) for _ in range(4))
    
    return f"{clean_title}_{timestamp}_{random_suffix}"


def generate_agora_token(channel_name, user_id=0, role=PUBLISHER_ROLE, privilege_expired_ts=3600):
    """
    Generate a token for Agora video conferencing
    
    Args:
        channel_name (str): Channel name for the video call
        user_id (int): User ID (0 means any user)
        role (int): Role - publisher (1) or audience (2)
        privilege_expired_ts (int): Token expiration in seconds
    
    Returns:
        str: Agora token
    """
    if not AGORA_APP_ID or not AGORA_APP_CERTIFICATE:
        logger.warning("Agora credentials not properly configured")
        return None
    
    # Calculate expiration time (current time + expiration seconds)
    expiration_time_in_seconds = int(time.time()) + privilege_expired_ts
    
    try:
        # Generate token using RtcTokenBuilder
        token = RtcTokenBuilder.buildTokenWithUid(
            AGORA_APP_ID,
            AGORA_APP_CERTIFICATE, 
            channel_name, 
            user_id, 
            role, 
            expiration_time_in_seconds
        )
        return token
    except Exception as e:
        logger.error(f"Error generating Agora token: {str(e)}")
        return None


def create_agora_channel(title, scheduled_time, duration=60):
    """
    Create Agora video conferencing data for an interview
    
    Args:
        title (str): Title of the interview
        scheduled_time (datetime): Scheduled start time
        duration (int): Duration in minutes
    
    Returns:
        dict: Dictionary with Agora channel info:
              - channel_name: Name of the Agora channel
              - app_id: Agora App ID
              - token: Agora token (optional, can also be generated client-side)
    """
    try:
        # Check if we have proper Agora API credentials
        if not AGORA_APP_ID or not AGORA_APP_CERTIFICATE:
            logger.warning("Agora API credentials not properly configured")
            return None
        
        # Generate channel name
        channel_name = generate_channel_name(title, scheduled_time)
        
        # Calculate expiration time based on interview duration (add 30 min buffer)
        expiration_seconds = (duration + 30) * 60  
        
        # Generate token that will be valid for the interview duration plus buffer
        token = generate_agora_token(
            channel_name=channel_name,
            privilege_expired_ts=expiration_seconds
        )
        
        # Return Agora channel information
        return {
            'channel_name': channel_name,
            'app_id': AGORA_APP_ID,
            'token': token
        }
        
    except Exception as e:
        logger.error(f"Error creating Agora channel: {str(e)}")
        return None