import pickle
import numpy as np

def predict_resume_category_from_text(resume_text):
    """
    Predicts the category of a resume based on a pre-trained model using raw text input.
    
    Parameters:
    resume_text (str): Raw text content of the resume
    
    Returns:
    dict: A dictionary containing the prediction results with keys:
        - predicted_category: The predicted category of the resume
        - confidence_score: The confidence score of the prediction
        - relative_scores: Dictionary of relative scores for all categories
    """
    
    # Model file paths
    model_path = r"C:\Users\Administrator\Downloads\careeraipro1\CareerAiPro\static\models\clf.pkl"
    tfidf_path = r"C:\Users\Administrator\Downloads\careeraipro1\CareerAiPro\static\models\tfidf.pkl"
    encoder_path = r"C:\Users\Administrator\Downloads\careeraipro1\CareerAiPro\static\models\encoder.pkl"
    
    try:
        # Load the models
        with open(model_path, 'rb') as model_file:
            svc_model = pickle.load(model_file)
        
        with open(tfidf_path, 'rb') as tfidf_file:
            tfidf = pickle.load(tfidf_file)
        
        with open(encoder_path, 'rb') as encoder_file:
            le = pickle.load(encoder_file)
        
        # Check if the input text is valid
        if not resume_text or not isinstance(resume_text, str):
            raise ValueError("Invalid or empty resume text provided")
        
        # Preprocess the resume text using the TF-IDF vectorizer
        resume_tfidf = tfidf.transform([resume_text])
        resume_tfidf_dense = resume_tfidf.toarray()
        
        # Try to get decision scores if available
        try:
            decision_scores = svc_model.decision_function(resume_tfidf_dense)[0]
            prediction = svc_model.predict(resume_tfidf_dense)
            predicted_label = le.inverse_transform(prediction)[0]
            
            # Create mapping of classes to scores
            classes = le.inverse_transform(range(len(decision_scores))) if len(decision_scores) > 1 else [predicted_label]
            scores = dict(zip(classes, decision_scores)) if len(decision_scores) > 1 else {predicted_label: decision_scores}
            sorted_scores = {k: v for k, v in sorted(scores.items(), key=lambda item: item[1], reverse=True)}
            
            # Calculate confidence using softmax
            if len(sorted_scores) > 1:
                exp_scores = np.exp(decision_scores - np.max(decision_scores))
                confidence_scores = exp_scores / exp_scores.sum()
                confidence_dict = dict(zip(classes, confidence_scores))
                confidence_score = confidence_dict[predicted_label]
            else:
                confidence_score = 1.0
                
        except AttributeError:
            # Fallback if decision_function is not available
            prediction = svc_model.predict(resume_tfidf_dense)
            predicted_label = le.inverse_transform(prediction)[0]
            confidence_score = None
            sorted_scores = {"Note": "Confidence scores unavailable for this model configuration"}
        
        # Prepare results
        result = {
            "predicted_category": predicted_label,
            "confidence_score": confidence_score,
            "relative_scores": sorted_scores
        }
        
        return result
        
    except Exception as e:
        print(f"Prediction error: {e}")
        return None

# Example usage:
# resume_text = "Your resume text goes here..."
# result = predict_resume_category_from_text(resume_text)
# if result:
#     print(f"Category: {result['predicted_category']}")
#     if result['confidence_score'] is not None:
#         print(f"Confidence: {result['confidence_score']*100:.2f}%")