# assessment_engine.py
import cohere
from typing import Dict, List, Optional
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity
import json

class HolisticAssessmentEngine:
    def __init__(self, cohere_api_key: str):
        self.co = cohere.Client(cohere_api_key)
        self.dimension_weights = {
            'technical_skills': 0.35,
            'soft_skills': 0.25,
            'cultural_fit': 0.20,
            'experience': 0.15,
            'education': 0.05
        }
    
    async def assess_candidate(self, resume_text: str, job_description: str) -> Dict:
        """Main method to perform holistic assessment"""
        # Step 1: Extract and structure information
        structured_data = await self._extract_information(resume_text)
        
        # Step 2: Analyze each dimension
        technical_analysis = self._analyze_technical_skills(
            structured_data.get('skills', []), 
            job_description
        )
        
        soft_skills_analysis = self._analyze_soft_skills(
            structured_data.get('experience', []),
            structured_data.get('projects', [])
        )
        
        cultural_fit_analysis = self._analyze_cultural_fit(
            structured_data.get('values', []),
            job_description
        )
        
        # Step 3: Generate comprehensive report
        report = self._generate_report(
            technical_analysis,
            soft_skills_analysis,
            cultural_fit_analysis,
            structured_data
        )
        
        # Step 4: Calculate overall score
        overall_score = self._calculate_overall_score(
            technical_analysis['score'],
            soft_skills_analysis['score'],
            cultural_fit_analysis['score'],
            structured_data['experience_years']
        )
        
        return {
            'overall_score': overall_score,
            'report': report,
            'technical_analysis': technical_analysis,
            'soft_skills_analysis': soft_skills_analysis,
            'cultural_fit_analysis': cultural_fit_analysis,
            'job_recommendations': self._generate_job_recommendations(structured_data)
        }

    async def _extract_information(self, text: str) -> Dict:
        """Use Cohere to extract structured information from resume text"""
        prompt = f"""
        Extract the following information from this resume text in JSON format:
        - skills: list of technical skills
        - experience: list of job experiences with title, company, duration
        - education: list of degrees with institution and year
        - projects: list of key projects
        - values: inferred core values from the text
        
        Resume Text: {text}
        
        Return only valid JSON without any additional text.
        """
        
        response = self.co.generate(
            model='command',
            prompt=prompt,
            max_tokens=1000,
            temperature=0.3
        )
        
        return self._parse_cohere_response(response.generations[0].text)

    def _analyze_technical_skills(self, skills: List[str], job_description: str) -> Dict:
        """Analyze technical skills match with job requirements"""
        # Embed both skills and job description
        skills_text = ", ".join(skills)
        embeddings = self.co.embed(
            texts=[skills_text, job_description],
            model='embed-english-v3.0',
            input_type='classification'
        ).embeddings
        
        # Calculate similarity
        similarity = cosine_similarity(
            [embeddings[0]],
            [embeddings[1]]
        )[0][0]
        
        score = float(np.interp(similarity, [-1, 1], [0, 100]))
        
        # Identify missing skills
        missing_skills = self._identify_missing_skills(skills, job_description)
        
        return {
            'score': score,
            'skills': skills,
            'skills_match': similarity,
            'missing_skills': missing_skills
        }

    def _analyze_soft_skills(self, experiences: List[Dict], projects: List[str]) -> Dict:
        """Analyze soft skills from experience and project descriptions"""
        combined_text = "\n".join([
            exp.get('description', '') for exp in experiences
        ] + projects)
        
        prompt = f"""
        Analyze the following professional experiences and projects to identify 
        the top 5 soft skills demonstrated. Return a JSON with:
        - skills: list of soft skills
        - evidence: text excerpts supporting each skill
        - confidence: confidence score for each skill (0-1)
        
        Text: {combined_text}
        """
        
        response = self.co.generate(
            model='command',
            prompt=prompt,
            max_tokens=500,
            temperature=0.2
        )
        
        analysis = self._parse_cohere_response(response.generations[0].text)
        
        # Calculate overall soft skills score
        if analysis and 'skills' in analysis:
            avg_confidence = sum(
                skill['confidence'] for skill in analysis['skills']
            ) / len(analysis['skills'])
            score = float(np.interp(avg_confidence, [0, 1], [0, 100]))
        else:
            score = 0
        
        return {
            'score': score,
            'analysis': analysis
        }

    def _analyze_cultural_fit(self, values: List[str], job_description: str) -> Dict:
        """Analyze cultural fit between candidate values and company culture"""
        if not values:
            return {'score': 0, 'analysis': 'No values detected'}
            
        # Extract company values from job description
        prompt = f"""
        Extract the company's core values and culture from this job description.
        Return as a JSON list of values.
        
        Job Description: {job_description}
        """
        
        response = self.co.generate(
            model='command',
            prompt=prompt,
            max_tokens=300,
            temperature=0.1
        )
        
        company_values = self._parse_cohere_response(response.generations[0].text)
        
        if not company_values or not isinstance(company_values, list):
            return {'score': 0, 'analysis': 'Could not extract company values'}
        
        # Calculate alignment
        values_text = "Candidate values: " + ", ".join(values)
        company_values_text = "Company values: " + ", ".join(company_values)
        
        embeddings = self.co.embed(
            texts=[values_text, company_values_text],
            model='embed-english-v3.0',
            input_type='classification'
        ).embeddings
        
        similarity = cosine_similarity(
            [embeddings[0]],
            [embeddings[1]]
        )[0][0]
        
        score = float(np.interp(similarity, [-1, 1], [0, 100]))
        
        return {
            'score': score,
            'candidate_values': values,
            'company_values': company_values,
            'alignment_score': similarity
        }

    def _generate_report(self, technical: Dict, soft: Dict, cultural: Dict, data: Dict) -> str:
        """Generate comprehensive assessment report"""
        prompt = f"""
        Create a professional candidate assessment report with the following sections:
        
        1. Summary (overall impression)
        2. Technical Skills Assessment:
           - Strengths: {technical['skills']}
           - Areas for development: {technical.get('missing_skills', [])}
           - Match score: {technical['score']}/100
        
        3. Soft Skills Assessment:
           # Fix the list comprehension by adding the missing closing brace
        - Key soft skills: {[s['skill'] for s in soft['analysis']['skills']]}
           - Supporting evidence: {soft['analysis']['evidence']}
           - Score: {soft['score']}/100
        
        4. Cultural Fit:
           - Candidate values: {cultural['candidate_values']}
           - Company values: {cultural['company_values']}
           - Alignment score: {cultural['score']}/100
        
        5. Recommendations:
           - Development areas
           - Suggested interview questions
           - Overall recommendation
        
        Write in professional HR tone, be constructive but honest.
        """
        
        response = self.co.generate(
            model='command',
            prompt=prompt,
            max_tokens=1500,
            temperature=0.4
        )
        
        return response.generations[0].text

    def _calculate_overall_score(self, technical: float, soft: float, cultural: float, exp_years: int) -> float:
        """Calculate weighted overall score"""
        exp_score = min(10, exp_years) * 2  # Max 20 points for experience
        
        weighted_sum = (
            self.dimension_weights['technical_skills'] * technical +
            self.dimension_weights['soft_skills'] * soft +
            self.dimension_weights['cultural_fit'] * cultural +
            self.dimension_weights['experience'] * exp_score
        )
        
        return round(weighted_sum, 1)

    def _generate_job_recommendations(self, candidate_data: Dict) -> List[Dict]:
        """Generate job role recommendations based on profile"""
        profile_summary = f"""
        Candidate Profile:
        - Skills: {candidate_data.get('skills', [])}
        - Experience: {len(candidate_data.get('experience', []))} positions
        - Education: {candidate_data.get('education', [])}
        - Values: {candidate_data.get('values', [])}
        """
        
        prompt = f"""
        Based on this candidate profile, suggest 3-5 ideal job roles that would 
        be a good fit. For each role, include:
        - Job title
        - Industry
        - Reason for recommendation
        - Fit score (1-10)
        
        Return as a JSON list of recommendations.
        
        Profile: {profile_summary}
        """
        
        response = self.co.generate(
            model='command',
            prompt=prompt,
            max_tokens=800,
            temperature=0.3
        )
        
        return self._parse_cohere_response(response.generations[0].text)

    def _identify_missing_skills(self, candidate_skills: List[str], job_description: str) -> List[str]:
        """Identify skills mentioned in JD but missing in candidate profile"""
        prompt = f"""
        Compare these candidate skills with the job description and list any 
        important skills mentioned in the JD that are missing from the candidate's skills.
        Return as a JSON list.
        
        Candidate Skills: {candidate_skills}
        Job Description: {job_description}
        """
        
        response = self.co.generate(
            model='command',
            prompt=prompt,
            max_tokens=300,
            temperature=0.1
        )
        
        return self._parse_cohere_response(response.generations[0].text) or []
def _parse_cohere_response(self, text: str) -> Optional[Dict]:
    """Helper to parse Cohere's JSON responses"""
    try:
        # Extract JSON from potentially messy response
        start = text.find('{')
        end = text.rfind('}') + 1
        if start >= 0 and end > start:
            return json.loads(text[start:end])
        else:
            return None
    except Exception as e:
        # Proper error handling
        print(f"Error parsing Cohere response: {str(e)}")
        return None