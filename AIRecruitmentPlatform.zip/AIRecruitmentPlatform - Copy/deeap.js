const { createClient } = require("@deepgram/sdk");

const transcribeUrl = async () => {
  // The API key we created in step 3
  const deepgramApiKey = "50055c753a1c2457a7494fdaff83f9fe394feea1";

  // Hosted sample file
  const url = "https://storage.googleapis.com/sermons__2024/Bro%20Benson%201%20narumoru%20dec.m4a";

  // Initializes the Deepgram SDK
  const deepgram = createClient(deepgramApiKey);

  const { result, error } = await deepgram.listen.prerecorded.transcribeUrl(
    { url },
    { smart_format: true, model: 'nova-2', language: 'en-US' },
  );

  if (error) throw error;
  if (!error) console.dir(result, {depth: null});
};

transcribeUrl();


//////////local file 

// index.js (node example)

const { createClient } = require("@deepgram/sdk");
const fs = require("fs");

const transcribeFile = async () => {
  // STEP 1: Create a Deepgram client using the API key
  const deepgram = createClient(process.env.DEEPGRAM_API_KEY);

  // STEP 2: Call the transcribeFile method with the audio payload and options
  const { result, error } = await deepgram.listen.prerecorded.transcribeFile(
    // path to the audio file
    fs.readFileSync("spacewalk.mp3"),
    // STEP 3: Configure Deepgram options for audio analysis
    {
      model: "nova-3",
      smart_format: true,
    }
  );

  if (error) throw error;
  // STEP 4: Print the results
  if (!error) console.dir(result, { depth: null });
};

transcribeFile();

